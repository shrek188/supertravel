import { NextApiRequest } from 'next';
import prisma from './prisma';

// Helper to safely serialize errors
function serializeError(error: any) {
    if (!error) return { message: 'Unknown error' };
    
    return {
        message: error.message || 'Unknown error',
        name: error.name,
        code: error.code,
        details: error.details,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
        ...(typeof error === 'object' ? error : {})
    };
}

export async function logApiCall(
    req: NextApiRequest,
    response: any,
    status: number,
    duration: number
) {
    try {
        await prisma.apiLog.create({
            data: {
                endpoint: req.url || 'unknown',
                request: {
                    query: req.query || {},
                    body: req.body || {},
                    method: req.method || 'unknown'
                },
                response: response || {},
                status: status,
                duration: duration
            }
        });
    } catch (error) {
        console.error('Failed to log API call:', serializeError(error));
    }
}

export async function logError(message: string, context: any = {}) {
    const timestamp = new Date().toISOString();
    
    // Ensure errors in context are properly serialized
    if (context.error) {
        context.error = serializeError(context.error);
    }
    
    const logEntry = {
        timestamp,
        message,
        ...context,
    };
    
    console.error(JSON.stringify(logEntry, null, 2));
    
    // Only attempt database logging if we're on the server side
    if (typeof window === 'undefined') {
        try {
            await prisma.errorLog.create({
                data: {
                    message,
                    context: logEntry,
                    timestamp: new Date(timestamp)
                }
            });
        } catch (error) {
            console.error('Failed to save error log to database:', serializeError(error));
        }
    }
    
    return logEntry;
}

export async function logTravelApiError(error: any, context: any = {}) {
    const errorDetails = {
        ...serializeError(error),
        ...context,
    };

    try {
        await prisma.travelLog.create({
            data: {
                type: 'ERROR',
                message: errorDetails.message,
                details: errorDetails,
                timestamp: new Date()
            }
        });
    } catch (dbError) {
        console.error('Failed to save travel error log:', serializeError(dbError));
    }
}