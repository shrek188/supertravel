import Amadeus from 'amadeus';
import prisma from './prisma';
import { logError } from './logging';

// Initialize the Amadeus client with API credentials
let amadeus: Amadeus;
try {
    amadeus = new Amadeus({
        clientId: process.env.AMADEUS_API_KEY,
        clientSecret: process.env.AMADEUS_API_SECRET
    });
} catch (error) {
    logError('Failed to initialize Amadeus SDK', { error });
    // Create a dummy instance to prevent undefined errors
    amadeus = new Amadeus({
        clientId: 'dummy',
        clientSecret: 'dummy'
    });
}

// Get stored token from database
async function getStoredToken(): Promise<string | null> {
    try {
        const token = await prisma.amadeusToken.findFirst({
            orderBy: { createdAt: 'desc' }
        });

        if (token && token.expiresAt > new Date()) {
            return token.accessToken;
        }

        return null;
    } catch (error) {
        logError('Error getting stored Amadeus token', { error });
        return null;
    }
}

// Save token to database
async function saveTokenToStorage(accessToken: string, expiresIn: number): Promise<void> {
    try {
        const expiresAt = new Date(Date.now() + expiresIn * 1000);
        await prisma.amadeusToken.create({
            data: {
                accessToken,
                expiresAt
            }
        });
    } catch (error) {
        logError('Error saving Amadeus token', { error });
    }
}

// Get fresh Amadeus access token
async function getAmadeusAccessToken(): Promise<string> {
    const storedToken = await getStoredToken();
    if (storedToken) {
        return storedToken;
    }

    try {
        const response = await fetch('https://test.api.amadeus.com/v1/security/oauth2/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                grant_type: 'client_credentials',
                client_id: process.env.AMADEUS_API_KEY!,
                client_secret: process.env.AMADEUS_API_SECRET!,
            }),
        });

        const data = await response.json();
        if (data.access_token) {
            await saveTokenToStorage(data.access_token, data.expires_in);
            return data.access_token;
        } else {
            throw new Error('No access token in response');
        }
    } catch (error) {
        logError('Failed to refresh Amadeus token', { error });
        throw new Error('Failed to obtain Amadeus access token');
    }
}

// Search flights using Amadeus API
async function searchFlights(params: any) {
    try {
        const accessToken = await getAmadeusAccessToken();
        const response = await fetch('https://test.api.amadeus.com/v2/shopping/flight-offers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify(params)
        });

        if (!response.ok) {
            // If token is invalid, try one more time with a fresh token
            if (response.status === 401) {
                await prisma.amadeusToken.deleteMany();
                const newToken = await getAmadeusAccessToken();
                const retryResponse = await fetch('https://test.api.amadeus.com/v2/shopping/flight-offers', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${newToken}`
                    },
                    body: JSON.stringify(params)
                });
                
                if (!retryResponse.ok) {
                    throw new Error(`Amadeus API error: ${retryResponse.status}`);
                }
                return await retryResponse.json();
            }
            throw new Error(`Amadeus API error: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        logError('Error in searchFlights', { error, params });
        // Fallback to SDK if direct API call fails
        return useAmadeusSdk('/shopping/flight-offers', params);
    }
}

// Custom fetch function that handles both token types
const customAmadeusRequest = async (path: string, params?: Record<string, any>) => {
    try {
        // For flight search, use the dedicated function
        if (path === '/shopping/flight-offers' && params) {
            return await searchFlights(params);
        }

        const accessToken = await getAmadeusAccessToken();
        const baseUrl = 'https://test.api.amadeus.com/v2';
        const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
        const url = `${baseUrl}${path}${queryString}`;

        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            // If token is invalid, try one more time with a fresh token
            if (response.status === 401) {
                // Force new token by clearing database
                await prisma.amadeusToken.deleteMany();
                const newToken = await getAmadeusAccessToken();
                const retryResponse = await fetch(url, {
                    headers: {
                        'Authorization': `Bearer ${newToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                
                if (!retryResponse.ok) {
                    throw new Error(`Amadeus API error: ${retryResponse.status}`);
                }
                return await retryResponse.json();
            }
            throw new Error(`Amadeus API error: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        logError('Error in customAmadeusRequest', { error, path, params });
        // Fallback to SDK if direct API call fails
        return useAmadeusSdk(path, params);
    }
};

// Helper function to use the Amadeus SDK with retry logic
const useAmadeusSdk = async (path: string, params?: Record<string, any>, retryCount = 0) => {
    try {
        if (path === '/shopping/flight-offers') {
            const result = await amadeus.shopping.flightOffersSearch.get(params);
            return { data: result.data };
        }
        if (path === '/shopping/hotel-offers') {
            const result = await amadeus.shopping.hotelOffers.get(params);
            return { data: result.data };
        }
        throw new Error('Unsupported Amadeus API endpoint');
    } catch (error: any) {
        // Handle rate limiting with exponential backoff
        if (error.response?.statusCode === 429 && retryCount < 3) {
            const delay = Math.pow(2, retryCount) * 1000; // exponential backoff: 1s, 2s, 4s
            await new Promise(resolve => setTimeout(resolve, delay));
            return useAmadeusSdk(path, params, retryCount + 1);
        }

        logError('Error using Amadeus SDK', { error, path, params });
        throw error;
    }
};

// Export both the SDK instance and the custom request function
export { amadeus as default, customAmadeusRequest, searchFlights };