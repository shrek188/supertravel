import { FlightOffer } from "@/types/flight"

export const formatFlightDataForChat = (flightOffer: FlightOffer): string => {
  const itinerary = flightOffer.itineraries[0];
  const firstSegment = itinerary.segments[0];
  
  const formatDateTime = (dateTimeStr: string) => {
    const date = new Date(dateTimeStr);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    });
  };

  const formatDuration = (duration: string) => {
    return duration
      .replace('PT', '')
      .replace('H', 'h ')
      .replace('M', 'm');
  };

  return `✈️ Flight ${firstSegment.carrierCode}${firstSegment.number}
📍 Departure: ${firstSegment.departure.iataCode} 🕒 ${formatDateTime(firstSegment.departure.at)}
📍 Arrival: ${firstSegment.arrival.iataCode} 🕒 ${formatDateTime(firstSegment.arrival.at)}
💺 Available seats: ${flightOffer.numberOfBookableSeats}
⏳ Duration: ${formatDuration(firstSegment.duration)}
💰 Price: ${flightOffer.price.currency} ${flightOffer.price.total}`;
};