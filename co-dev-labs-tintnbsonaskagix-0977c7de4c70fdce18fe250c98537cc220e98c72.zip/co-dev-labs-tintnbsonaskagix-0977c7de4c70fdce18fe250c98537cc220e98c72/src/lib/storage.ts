import { createClient } from '@/util/supabase/component';
import { logError } from '@/lib/logging';

export const STORAGE_BUCKET = 'supertravel-mvp';
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

export interface UploadResult {
  url: string;
  path: string;
}

async function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function verifyBucket(supabase: any, userId: string): Promise<boolean> {
  try {
    // Try to list files in the bucket first
    const { data: files, error: listError } = await supabase
      .storage
      .from(STORAGE_BUCKET)
      .list('');

    if (!listError) {
      console.log('Bucket is accessible:', { bucket: STORAGE_BUCKET });
      return true;
    }

    console.log('Initial bucket access check failed, attempting initialization:', { error: listError });

    // Try to initialize the bucket through the API
    const response = await fetch('/api/storage/init-bucket', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    const result = await response.json();

    if (!response.ok) {
      console.error('Bucket initialization failed:', result);
      throw new Error(result.error || 'Failed to initialize storage bucket');
    }

    console.log('Bucket initialization successful:', result);

    // Verify access after initialization
    const { error: verifyError } = await supabase
      .storage
      .from(STORAGE_BUCKET)
      .list('');

    if (verifyError) {
      console.error('Post-initialization verification failed:', { error: verifyError });
      throw new Error('Failed to verify bucket access after initialization');
    }

    return true;
  } catch (error: any) {
    console.error('Bucket verification failed:', { error });
    logError('Failed to verify bucket', {
      error,
      bucket: STORAGE_BUCKET,
      userId
    });
    return false;
  }
}

export async function uploadMedia(file: File, userId: string): Promise<UploadResult> {
  if (!file) {
    throw new Error('No file provided');
  }

  if (file.size > MAX_FILE_SIZE) {
    const error = `File size exceeds ${MAX_FILE_SIZE / 1024 / 1024}MB limit`;
    logError('File size validation failed', { 
      error,
      fileSize: file.size,
      maxSize: MAX_FILE_SIZE,
      userId 
    });
    throw new Error(error);
  }

  const supabase = createClient();
  
  // Generate a unique file name
  const fileExt = file.name.split('.').pop();
  const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
  const filePath = `${userId}/${fileName}`;

  console.log('Starting file upload:', {
    originalName: file.name,
    size: file.size,
    type: file.type,
    path: filePath,
    bucket: STORAGE_BUCKET,
    userId
  });

  // Verify bucket exists and is accessible
  const bucketExists = await verifyBucket(supabase, userId);
  if (!bucketExists) {
    throw new Error(`Storage bucket ${STORAGE_BUCKET} is not available`);
  }

  let lastError = null;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      console.log(`Upload attempt ${attempt}/${MAX_RETRIES}`);

      // Attempt upload
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(STORAGE_BUCKET)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: attempt > 1 // Allow upsert on retry attempts
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      if (!uploadData) {
        throw new Error('Upload completed but no data returned');
      }

      // Get public URL
      const { data: { publicUrl }, error: urlError } = supabase.storage
        .from(STORAGE_BUCKET)
        .getPublicUrl(filePath);

      if (urlError || !publicUrl) {
        console.error('Failed to get public URL:', urlError);
        throw urlError || new Error('Failed to get public URL');
      }

      console.log('Upload successful:', {
        path: filePath,
        url: publicUrl,
        userId,
        attempt
      });

      return {
        url: publicUrl,
        path: filePath
      };
    } catch (error: any) {
      lastError = error;
      console.error(`Upload attempt ${attempt} failed:`, error);
      logError(`Upload attempt ${attempt} failed`, { 
        error,
        bucket: STORAGE_BUCKET,
        filePath,
        userId,
        attempt
      });

      if (attempt < MAX_RETRIES) {
        await delay(RETRY_DELAY * attempt); // Exponential backoff
        continue;
      }
    }
  }

  // If we get here, all attempts failed
  const finalError = new Error(`Failed to upload file after ${MAX_RETRIES} attempts: ${lastError?.message || 'Unknown error'}`);
  console.error('All upload attempts failed:', finalError);
  logError('All upload attempts failed', { 
    error: lastError,
    bucket: STORAGE_BUCKET,
    filePath,
    userId,
    attempts: MAX_RETRIES
  });
  
  throw finalError;
}