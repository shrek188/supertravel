import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import Link from "next/link";
import { useEffect, useState } from "react";

interface Activity {
  id: string;
  title: string;
  type: "like" | "bookmark";
  date: string;
}

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const response = await fetch('/api/user/activities');
        
        if (!response.ok) {
          throw new Error('Failed to fetch activities');
        }
        
        const data = await response.json();
        setActivities(data);
      } catch (error) {
        console.error('Failed to fetch activities:', error);
        setError('Unable to load your recent activities. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    if (user) {
      fetchActivities();
    }
  }, [user]);

  const userInitials = user?.email 
    ? user.email.substring(0, 2).toUpperCase() 
    : "US";

  return (
    <div className="min-h-screen bg-background">
      <main className="container mx-auto p-6 space-y-6">
        {/* Profile Section */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Profile</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center space-x-4">
              <Avatar className="h-20 w-20">
                <AvatarFallback className="text-lg">{userInitials}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-medium">{user?.email}</h3>
                <p className="text-sm text-muted-foreground">Member since {new Date().toLocaleDateString()}</p>
                <Button
                  onClick={() => signOut()}
                  variant="ghost"
                  className="mt-2"
                >
                  Log Out
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Link href="/chat" className="block">
                <Button className="w-full" size="lg">
                  Talk to AI Travel Assistant
                </Button>
              </Link>
              <Link href="/explore" className="block">
                <Button variant="outline" className="w-full" size="lg">
                  Explore Destinations
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Activity Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {error ? (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : (
              <Tabs defaultValue="all" className="w-full">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="likes">Likes</TabsTrigger>
                  <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
                </TabsList>
                
                <TabsContent value="all" className="mt-4">
                  {isLoading ? (
                    <p className="text-muted-foreground">Loading activities...</p>
                  ) : activities.length > 0 ? (
                    <div className="space-y-4">
                      {activities.map((activity) => (
                        <div
                          key={activity.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div>
                            <h4 className="font-medium">{activity.title}</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(activity.date).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {activity.type === 'like' ? '❤️' : '🔖'}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No recent activity to show.</p>
                  )}
                </TabsContent>
                
                <TabsContent value="likes" className="mt-4">
                  {activities.filter(a => a.type === 'like').length > 0 ? (
                    <div className="space-y-4">
                      {activities
                        .filter(a => a.type === 'like')
                        .map((activity) => (
                          <div
                            key={activity.id}
                            className="flex items-center justify-between p-4 border rounded-lg"
                          >
                            <div>
                              <h4 className="font-medium">{activity.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                {new Date(activity.date).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-sm">❤️</div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No liked posts yet.</p>
                  )}
                </TabsContent>
                
                <TabsContent value="bookmarks" className="mt-4">
                  {activities.filter(a => a.type === 'bookmark').length > 0 ? (
                    <div className="space-y-4">
                      {activities
                        .filter(a => a.type === 'bookmark')
                        .map((activity) => (
                          <div
                            key={activity.id}
                            className="flex items-center justify-between p-4 border rounded-lg"
                          >
                            <div>
                              <h4 className="font-medium">{activity.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                {new Date(activity.date).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-sm">🔖</div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No bookmarked destinations yet.</p>
                  )}
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}