import React from "react";
import Head from "next/head";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <Head>
        <title>Super Travel AI - Your Intelligent Travel Companion</title>
        <meta name="description" content="AI-powered travel recommendations, exclusive deals, and personalized experiences" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="bg-background min-h-screen flex flex-col">
        <Header />
        
        {/* Hero Section */}
        <main className="flex-1">
          <section className="py-20 px-4 md:px-6 text-center">
            <div className="max-w-4xl mx-auto space-y-4">
              <Badge variant="secondary" className="bg-purple-900/30 text-purple-300 mb-4">
                AI-Powered Travel Experience
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 to-purple-200 bg-clip-text text-transparent">
                Your Personal AI Travel Assistant
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
                Experience travel like never before with AI-driven recommendations, exclusive deals, and a community of passionate travelers.
              </p>
              <div className="flex gap-4 justify-center mt-8">
                <Link href="/signup">
                  <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                    Get Started Free
                  </Button>
                </Link>
                <Link href="/login">
                  <Button size="lg" variant="outline">
                    Sign In
                  </Button>
                </Link>
              </div>
            </div>
          </section>

          {/* Features Grid */}
          <section className="py-16 px-4 md:px-6 bg-black/20">
            <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">Explore</CardTitle>
                  <CardDescription>
                    Discover curated destinations and authentic travel experiences from our community
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">VIP Benefits</CardTitle>
                  <CardDescription>
                    Access exclusive deals, personalized recommendations, and premium content
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">Share Stories</CardTitle>
                  <CardDescription>
                    Create and share your travel experiences with a community of passionate travelers
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">AI Recommendations</CardTitle>
                  <CardDescription>
                    Get personalized travel suggestions based on your preferences and behavior
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">Real-time Support</CardTitle>
                  <CardDescription>
                    Instant solutions for travel issues with context-aware AI assistance
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-black/40 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300">Smart Planning</CardTitle>
                  <CardDescription>
                    Effortlessly plan your trips with AI-powered itinerary suggestions
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20 px-4 md:px-6 text-center">
            <div className="max-w-3xl mx-auto space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-purple-300">
                Start Your AI-Enhanced Travel Journey
              </h2>
              <p className="text-muted-foreground text-lg">
                Join thousands of travelers who are already experiencing the future of travel planning
              </p>
              <Link href="/signup">
                <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                  Join Now
                </Button>
              </Link>
            </div>
          </section>
        </main>
      </div>
    </>
  );
}