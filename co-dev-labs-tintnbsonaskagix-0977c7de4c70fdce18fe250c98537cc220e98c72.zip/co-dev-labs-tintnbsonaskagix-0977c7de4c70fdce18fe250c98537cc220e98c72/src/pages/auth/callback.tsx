import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { createClient } from '@/util/supabase/component'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from "@/components/ui/use-toast"

export default function AuthCallback() {
  const router = useRouter()
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    const handleAuthCallback = async () => {
      const { error } = await supabase.auth.getSession()
      
      if (error) {
        console.error('Auth callback error:', {
          message: error.message,
          status: error.status,
          name: error.name,
          timestamp: new Date().toISOString(),
          url: window.location.href,
          origin: window.location.origin
        })

        toast({
          variant: "destructive",
          title: "Authentication Error",
          description: "There was a problem completing the authentication. Please try again.",
        })

        // Redirect to login page after error
        router.push('/login')
        return
      }
    }

    handleAuthCallback()

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state change:', {
        event,
        userId: session?.user?.id,
        timestamp: new Date().toISOString(),
        origin: window.location.origin
      })

      if (event === 'SIGNED_IN' && session?.user) {
        try {
          const { createUser } = useAuth()
          await createUser(session.user)
          
          toast({
            title: "Welcome!",
            description: "You have successfully signed in.",
          })
          
          router.push('/dashboard')
        } catch (error: any) {
          console.error('Error in auth callback:', {
            error: error.message,
            stack: error.stack,
            event,
            userId: session?.user?.id,
            timestamp: new Date().toISOString()
          })

          toast({
            variant: "destructive",
            title: "Error",
            description: "There was a problem setting up your account. Please try again.",
          })
          
          router.push('/login')
        }
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [router])

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <h2 className="text-lg font-semibold">Completing authentication...</h2>
        <p className="text-sm text-muted-foreground">Please wait while we redirect you.</p>
      </div>
    </div>
  )
}