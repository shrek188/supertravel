import { NextApiRequest, NextApiResponse } from 'next';
import { customAmadeusRequest } from '@/lib/amadeus';
import prisma from '@/lib/prisma';
import { logError } from '@/lib/logging';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    const startTime = Date.now();
    let responseData;
    let statusCode = 200;

    try {
        const { cityCode, checkInDate, checkOutDate, adults } = req.query;

        // Validate required parameters
        if (!cityCode || !checkInDate || !checkOutDate || !adults) {
            statusCode = 400;
            throw new Error('Missing required parameters: cityCode, checkInDate, checkOutDate, and adults are required');
        }

        // Validate date format and logic
        const checkInDateObj = new Date(checkInDate as string);
        const checkOutDateObj = new Date(checkOutDate as string);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (isNaN(checkInDateObj.getTime()) || isNaN(checkOutDateObj.getTime())) {
            statusCode = 400;
            throw new Error('Invalid date format. Please use YYYY-MM-DD format');
        }

        if (checkInDateObj < today) {
            statusCode = 400;
            throw new Error('Check-in date cannot be in the past');
        }

        if (checkOutDateObj <= checkInDateObj) {
            statusCode = 400;
            throw new Error('Check-out date must be after check-in date');
        }

        // Validate adults number
        const adultsNum = Number(adults);
        if (isNaN(adultsNum) || adultsNum < 1 || adultsNum > 9) {
            statusCode = 400;
            throw new Error('Number of adults must be between 1 and 9');
        }

        // Make API request
        let result;
        try {
            result = await customAmadeusRequest('/shopping/hotel-offers', {
                cityCode,
                checkInDate,
                checkOutDate,
                adults: adultsNum,
                roomQuantity: 1,
                bestRateOnly: true
            });

            if (!result || !result.data) {
                logError('Invalid Amadeus API response', { result });
                throw new Error('No hotel data available for the selected criteria');
            }

            if (!Array.isArray(result.data)) {
                logError('Invalid Amadeus API response format', { result });
                throw new Error('Invalid response format from hotel search');
            }
        } catch (error: any) {
            logError('Amadeus API request failed', {
                error: error.message,
                params: {
                    cityCode,
                    checkInDate,
                    checkOutDate,
                    adults: adultsNum
                }
            });
            throw new Error('Failed to fetch hotel offers. Please try again later.');
        }

        responseData = {
            data: result.data.map((hotel: any) => ({
                hotelId: hotel.hotel?.hotelId,
                name: hotel.hotel?.name,
                rating: hotel.hotel?.rating,
                description: hotel.hotel?.description,
                amenities: hotel.hotel?.amenities,
                address: hotel.hotel?.address,
                media: hotel.hotel?.media,
                offers: hotel.offers?.map((offer: any) => ({
                    id: offer.id,
                    checkInDate: offer.checkInDate,
                    checkOutDate: offer.checkOutDate,
                    price: offer.price,
                    room: offer.room,
                    policies: offer.policies
                }))
            })),
            meta: {
                count: result.data.length,
                cityCode,
                checkInDate,
                checkOutDate,
                adults: adultsNum
            }
        };

        // Log successful API call
        await prisma.apiLog.create({
            data: {
                endpoint: '/api/travel/hotels',
                request: {
                    query: req.query,
                    method: req.method
                },
                response: {
                    status: 'success',
                    count: responseData.data.length
                },
                status: statusCode,
                duration: Date.now() - startTime
            }
        });

        if (responseData.data.length === 0) {
            return res.status(200).json({
                data: [],
                meta: responseData.meta,
                suggestions: [
                    'Try different dates',
                    'Consider alternative nearby destinations',
                    'Adjust the number of guests',
                    'Some destinations might have limited availability'
                ]
            });
        }

        return res.status(statusCode).json(responseData);
    } catch (error: any) {
        // Enhanced error logging
        logError('Hotel search error', {
            error: error.message,
            query: req.query,
            stack: error.stack,
            timestamp: new Date().toISOString()
        });

        statusCode = error.message.includes('Missing') || 
                    error.message.includes('Invalid') || 
                    error.message.includes('must be') ? 400 : 500;

        responseData = {
            error: error.message || 'Failed to fetch hotel offers',
            suggestions: [
                'Check if the city code is correct',
                'Make sure dates are in YYYY-MM-DD format',
                'Verify that check-out date is after check-in date',
                'Ensure the number of guests is between 1 and 9',
                'Try different dates or location'
            ]
        };

        // Log failed API call
        await prisma.apiLog.create({
            data: {
                endpoint: '/api/travel/hotels',
                request: {
                    query: req.query,
                    method: req.method
                },
                response: {
                    status: 'error',
                    error: error.message
                },
                status: statusCode,
                duration: Date.now() - startTime
            }
        });

        return res.status(statusCode).json(responseData);
    }
}