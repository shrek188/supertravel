import { NextApiRequest, NextApiResponse } from 'next';
import { customAmadeusRequest } from '@/lib/amadeus';
import { logApiCall, logTravelApiError } from '@/lib/logging';
import prisma from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'POST') {
        await logApiCall(req, { error: 'Method not allowed' }, 405, 0);
        return res.status(405).json({ error: 'Only POST method is allowed' });
    }

    const startTime = Date.now();
    let responseData;
    let statusCode = 200;

    try {
        // Log incoming request for debugging
        console.log('Flight search request:', {
            timestamp: new Date().toISOString(),
            body: req.body,
            headers: req.headers
        });

        // Handle both parameter naming conventions
        const {
            departureAirport: departure1,
            destinationAirport: destination1,
            origin: departure2,
            destination: destination2,
            departureDate,
            cabinClass = 'ECONOMY',
            travelers = 1
        } = req.body;

        const departureAirport = departure1 || departure2;
        const destinationAirport = destination1 || destination2;

        // Validate required parameters
        if (!departureAirport || !destinationAirport || !departureDate || !travelers) {
            const error = 'Missing required parameters: departureAirport, destinationAirport, departureDate, and travelers are required';
            await logTravelApiError(new Error(error), { requestBody: req.body });
            await logApiCall(req, { error }, 400, Date.now() - startTime);
            return res.status(400).json({ error });
        }

        // Validate airport codes (basic validation)
        if (departureAirport.length !== 3 || destinationAirport.length !== 3) {
            const error = 'Airport codes must be 3 characters long';
            await logTravelApiError(new Error(error), { 
                departureAirport, 
                destinationAirport 
            });
            await logApiCall(req, { error }, 400, Date.now() - startTime);
            return res.status(400).json({ error });
        }

        // Validate date
        const selectedDate = new Date(departureDate);
        const today = new Date();
        if (selectedDate < today) {
            const error = 'Departure date cannot be in the past';
            await logTravelApiError(new Error(error), { 
                selectedDate: selectedDate.toISOString(), 
                today: today.toISOString() 
            });
            await logApiCall(req, { error }, 400, Date.now() - startTime);
            return res.status(400).json({ error });
        }

        // Validate travelers
        if (isNaN(travelers) || travelers < 1 || travelers > 9) {
            const error = 'Number of travelers must be between 1 and 9';
            await logTravelApiError(new Error(error), { travelers });
            await logApiCall(req, { error }, 400, Date.now() - startTime);
            return res.status(400).json({ error });
        }

        const params = {
            originLocationCode: departureAirport.toUpperCase(),
            destinationLocationCode: destinationAirport.toUpperCase(),
            departureDate: selectedDate.toISOString().split('T')[0],
            adults: travelers,
            nonStop: false,
            max: 20,
            currencyCode: 'USD'
        };

        console.log('Calling Amadeus API with params:', JSON.stringify(params, null, 2));

        const result = await customAmadeusRequest('/shopping/flight-offers', params);

        if (!result || !result.data) {
            throw new Error('Invalid response from Amadeus API');
        }

        responseData = {
            data: result.data || [],
            suggestions: result.suggestions || []
        };

        // Log successful response
        console.log('Successful flight search:', {
            timestamp: new Date().toISOString(),
            flightsFound: responseData.data.length,
            searchParams: params
        });

        // Log the successful API call
        await prisma.apiLog.create({
            data: {
                endpoint: '/api/travel/flights',
                request: {
                    query: req.method === 'GET' ? req.query : {},
                    body: req.method === 'POST' ? req.body : {},
                    method: req.method
                },
                response: {
                    flightsCount: responseData.data.length,
                    hasSuggestions: responseData.suggestions.length > 0
                },
                status: statusCode,
                duration: Date.now() - startTime
            }
        });

        return res.status(statusCode).json(responseData);
    } catch (error: any) {
        console.error('Flight search error:', {
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
            requestBody: req.body
        });

        statusCode = error?.message && typeof error.message === 'string' && error.message.includes('Missing required parameters') ? 400 : 500;
        responseData = {
            data: [],
            error: error.message || 'Failed to fetch flight offers',
            suggestions: [
                'Try different dates',
                'Check airport codes',
                'Verify cabin class',
                'Make sure all required fields are filled'
            ]
        };

        // Log the error
        await logTravelApiError(error, {
            requestBody: req.body,
            statusCode,
            responseData
        });

        // Log the failed API call
        await prisma.apiLog.create({
            data: {
                endpoint: '/api/travel/flights',
                request: {
                    query: req.method === 'GET' ? req.query : {},
                    body: req.method === 'POST' ? req.body : {},
                    method: req.method
                },
                response: responseData,
                status: statusCode,
                duration: Date.now() - startTime,
                error: error.message
            }
        });

        return res.status(statusCode).json(responseData);
    }
}