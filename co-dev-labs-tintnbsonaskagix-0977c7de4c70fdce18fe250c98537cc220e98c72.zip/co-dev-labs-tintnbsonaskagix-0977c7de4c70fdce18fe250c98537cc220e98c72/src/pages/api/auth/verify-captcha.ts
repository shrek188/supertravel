import { NextApiRequest, NextApiResponse } from 'next';
import { verifyCaptcha } from '@/lib/captcha';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ success: false, message: 'Token is required' });
    }

    const isValid = await verifyCaptcha(token);

    if (!isValid) {
      return res.status(400).json({ success: false, message: 'Invalid CAPTCHA' });
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error verifying CAPTCHA:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
}