import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { email } = req.body;

    if (!email || email !== 'test@mvptest.com') {
      return res.status(400).json({ 
        error: 'Invalid request. This endpoint is only for resetting the test account.' 
      });
    }

    const supabase = createClient(req, res);

    // First, list users to find the test account
    const { data: users, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.error('Error listing users:', {
        error: listError,
        timestamp: new Date().toISOString()
      });
      return res.status(500).json({ error: 'Error fetching user data' });
    }

    const testUser = users.users.find(user => user.email === email);
    
    if (!testUser) {
      return res.status(404).json({ error: 'Test account not found' });
    }

    // Reset the password for the test account
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      testUser.id,
      { password: process.env.TEST_ACCOUNT_PASSWORD }
    );

    if (updateError) {
      console.error('Error resetting password:', {
        error: updateError,
        userId: testUser.id,
        timestamp: new Date().toISOString()
      });
      return res.status(500).json({ error: 'Failed to reset password' });
    }

    // Update email confirmation status if needed
    if (!testUser.email_confirmed_at) {
      const { error: confirmError } = await supabase.auth.admin.updateUserById(
        testUser.id,
        { email_confirm: true }
      );

      if (confirmError) {
        console.error('Error confirming email:', {
          error: confirmError,
          userId: testUser.id,
          timestamp: new Date().toISOString()
        });
      }
    }

    return res.status(200).json({ 
      message: 'Test account has been reset successfully',
      confirmed: true
    });

  } catch (error: any) {
    console.error('Unexpected error in reset-test-account:', {
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    return res.status(500).json({ error: 'Internal server error' });
  }
}