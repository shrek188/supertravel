import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import { logError } from '@/lib/logging';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const email = req.query.email as string;
  
  if (!email) {
    return res.status(400).json({ error: 'Email parameter is required' });
  }

  try {
    const supabase = createClient(req, res);
    
    const { data: user, error } = await supabase.auth.admin.getUserByEmail(email);

    if (error) {
      // If it's a not found error, return exists: false instead of an error
      if (error.status === 404) {
        return res.status(200).json({
          exists: false,
          user: null
        });
      }
      
      logError('Error checking user existence:', { error, email });
      return res.status(500).json({ error: 'Error checking user existence' });
    }

    return res.status(200).json({
      exists: !!user,
      user: user ? {
        id: user.id,
        email: user.email
      } : null
    });

  } catch (error) {
    logError('Error in check-users endpoint:', { error, email });
    return res.status(500).json({ error: 'Internal server error' });
  }
}