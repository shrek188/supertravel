import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { logger } from '@/lib/logging'

const destinations = [
  {
    name: "Kyoto, Japan",
    description: "Ancient temples, traditional gardens, and serene beauty",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800",
    featured: true,
  },
  {
    name: "Santorini, Greece",
    description: "Stunning white architecture and Mediterranean views",
    imageUrl: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800",
    featured: true,
  },
  {
    name: "Machu Picchu, Peru",
    description: "Ancient Incan citadel in the Andes Mountains",
    imageUrl: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=800",
    featured: true,
  },
  {
    name: "Banff, Canada",
    description: "Breathtaking mountain landscapes and crystal lakes",
    imageUrl: "https://images.unsplash.com/photo-1609861517208-e5b7b4cd4b87?w=800",
    featured: true,
  },
  {
    name: "Bali, Indonesia",
    description: "Tropical paradise with rich culture and beaches",
    imageUrl: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800",
    featured: true,
  }
];

const posts = [
  {
    title: "A Week in Ancient Kyoto",
    content: "Exploring the serene temples and gardens of Kyoto was a life-changing experience. The Fushimi Inari Shrine's thousands of torii gates created an unforgettable path through the mountain.",
    mediaUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800",
  },
  {
    title: "Sunset Magic in Santorini",
    content: "Watching the sunset from Oia was absolutely magical. The white buildings contrasting with the deep blue sea created a perfect canvas for nature's daily show.",
    mediaUrl: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800",
  },
  {
    title: "Hiking Machu Picchu at Dawn",
    content: "Reaching Machu Picchu for sunrise was worth every step of the climb. The ancient stones seemed to glow in the morning light, revealing the incredible engineering of the Incas.",
    mediaUrl: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=800",
  },
  {
    title: "Winter Wonderland in Banff",
    content: "Banff National Park in winter is a true wonderland. Skiing through pristine powder snow while surrounded by majestic peaks was an experience I'll never forget.",
    mediaUrl: "https://images.unsplash.com/photo-1609861517208-e5b7b4cd4b87?w=800",
  },
  {
    title: "Spiritual Journey in Bali",
    content: "From ancient temples to lush rice terraces, Bali offered a perfect blend of culture, nature, and spirituality. The local ceremonies and traditions were incredibly moving.",
    mediaUrl: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800",
  }
];

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    // Validate request method
    if (req.method !== 'POST') {
      logger.warn('Invalid method used for seed-data endpoint', { method: req.method });
      return res.status(405).json({ 
        success: false,
        message: 'Method not allowed. Only POST requests are accepted.'
      });
    }
    logger.info('Starting data seeding process')

    // First, check if we already have data
    const existingPosts = await prisma.post.count();
    const existingDestinations = await prisma.destination.count();

    if (existingPosts > 0 || existingDestinations > 0) {
      logger.info('Cleaning up existing data')
      // Clean up existing data in parallel
      await Promise.all([
        prisma.post.deleteMany({}),
        prisma.destination.deleteMany({})
      ]);
      logger.info('Existing data cleaned up')
    }

    logger.info('Creating test user')
    // Create test user if doesn't exist
    const testUser = await prisma.user.upsert({
      where: {
        email: 'test@supertravel.ai'
      },
      update: {},
      create: {
        id: '00000000-0000-0000-0000-000000000000',
        email: 'test@supertravel.ai'
      }
    });
    logger.info('Test user created/found:', { userId: testUser.id })

    logger.info('Creating destinations')
    // Create all destinations in parallel
    const createdDestinations = await prisma.$transaction(
      destinations.map(destination =>
        prisma.destination.create({
          data: destination
        })
      )
    );
    logger.info(`Created ${createdDestinations.length} destinations`)

    logger.info('Creating posts')
    // Create posts with media in parallel
    const postCreatePromises = posts.map((post, index) => {
      const { mediaUrl, ...postData } = post;
      return {
        ...postData,
        authorId: testUser.id,
        destinationId: createdDestinations[index % createdDestinations.length].id,
        likes: Math.floor(Math.random() * 100),
        media: {
          create: {
            url: mediaUrl,
            type: 'IMAGE'
          }
        }
      };
    });

    const createdPosts = await prisma.$transaction(
      postCreatePromises.map(postData =>
        prisma.post.create({
          data: postData,
          include: {
            media: true
          }
        })
      )
    );
    logger.info(`Created ${createdPosts.length} posts`)

    logger.info('Seed data creation completed successfully')
    return res.status(200).json({
      message: 'Seed data created successfully',
      destinations: createdDestinations.length,
      posts: createdPosts.length,
      testUser: testUser.id
    })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    logger.error('Error seeding data:', { error: errorMessage, stack: error instanceof Error ? error.stack : undefined });
    return res.status(500).json({ 
      success: false,
      message: 'Error seeding data',
      error: errorMessage,
      timestamp: new Date().toISOString()
    });
  }
}