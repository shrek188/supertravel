import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    // Get the user from Supabase auth
    const supabase = createClient(req, res)
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      console.error('Auth error:', authError)
      return res.status(401).json({ message: 'Unauthorized' })
    }

    // For now, we'll return some sample activities
    // In a real implementation, you would fetch this from your database
    const sampleActivities = [
      {
        id: '1',
        title: 'Paris Travel Guide',
        type: 'bookmark',
        date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() // 1 day ago
      },
      {
        id: '2',
        title: 'Tokyo Adventures',
        type: 'like',
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() // 2 days ago
      },
      {
        id: '3',
        title: 'New York City Tips',
        type: 'bookmark',
        date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days ago
      }
    ]

    return res.status(200).json(sampleActivities)
  } catch (error) {
    console.error('Error in /api/user/activities:', error)
    return res.status(500).json({ 
      message: 'Error fetching activities',
      error: process.env.NODE_ENV === 'development' ? error : undefined
    })
  }
}