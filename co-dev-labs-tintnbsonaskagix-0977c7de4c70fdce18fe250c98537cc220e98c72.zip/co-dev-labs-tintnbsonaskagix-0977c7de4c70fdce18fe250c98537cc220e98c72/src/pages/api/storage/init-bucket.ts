import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import { STORAGE_BUCKET } from '@/lib/storage';
import { logError } from '@/lib/logging';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    
    // Check if user is authenticated
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.log('Authentication failed:', { error: authError });
      throw new Error('Unauthorized');
    }

    console.log('Checking bucket existence:', { bucket: STORAGE_BUCKET });

    // First, check if bucket exists
    const { data: buckets, error: listError } = await supabase
      .storage
      .listBuckets();

    if (listError) {
      console.log('Failed to list buckets:', { error: listError });
      throw listError;
    }

    const existingBucket = buckets?.find(b => b.name === STORAGE_BUCKET);
    console.log('Bucket status:', { exists: !!existingBucket, bucket: STORAGE_BUCKET });

    if (!existingBucket) {
      console.log('Creating new bucket:', { bucket: STORAGE_BUCKET });
      
      try {
        // Create the bucket with public access
        const { data: createData, error: createError } = await supabase
          .storage
          .createBucket(STORAGE_BUCKET, {
            public: true,
            fileSizeLimit: 10485760, // 10MB
            allowedMimeTypes: ['image/*']
          });

        if (createError) {
          console.log('Failed to create bucket:', { error: createError });
          throw createError;
        }

        console.log('Bucket created successfully:', { bucket: STORAGE_BUCKET, data: createData });

        // Update the bucket's public access
        const { error: updateError } = await supabase
          .storage
          .updateBucket(STORAGE_BUCKET, {
            public: true,
            fileSizeLimit: 10485760,
            allowedMimeTypes: ['image/*']
          });

        if (updateError) {
          console.log('Failed to update bucket settings:', { error: updateError });
          throw updateError;
        }

        console.log('Bucket settings updated successfully');

      } catch (error: any) {
        // If bucket already exists but we couldn't see it, try to update it
        if (error.message?.includes('already exists')) {
          console.log('Bucket already exists, updating settings');
          const { error: updateError } = await supabase
            .storage
            .updateBucket(STORAGE_BUCKET, {
              public: true,
              fileSizeLimit: 10485760,
              allowedMimeTypes: ['image/*']
            });

          if (updateError) {
            console.log('Failed to update existing bucket:', { error: updateError });
            throw updateError;
          }
        } else {
          throw error;
        }
      }
    } else {
      // Update existing bucket settings
      const { error: updateError } = await supabase
        .storage
        .updateBucket(STORAGE_BUCKET, {
          public: true,
          fileSizeLimit: 10485760,
          allowedMimeTypes: ['image/*']
        });

      if (updateError) {
        console.log('Failed to update bucket settings:', { error: updateError });
        throw updateError;
      }
    }

    // Verify bucket is accessible
    const { data: verifyData, error: verifyError } = await supabase
      .storage
      .from(STORAGE_BUCKET)
      .list('');

    if (verifyError) {
      console.log('Failed to verify bucket access:', { error: verifyError });
      throw new Error(`Failed to verify bucket access: ${verifyError.message}`);
    }

    console.log('Bucket verification successful:', { bucket: STORAGE_BUCKET });

    return res.status(200).json({ 
      message: 'Storage bucket initialized successfully',
      bucket: STORAGE_BUCKET,
      exists: !!existingBucket
    });

  } catch (error: any) {
    console.error('Storage initialization error:', error);
    logError('Failed to initialize storage bucket', {
      error,
      bucket: STORAGE_BUCKET
    });

    return res.status(error.status || 500).json({
      error: error.message || 'Failed to initialize storage bucket',
      details: error
    });
  }
}