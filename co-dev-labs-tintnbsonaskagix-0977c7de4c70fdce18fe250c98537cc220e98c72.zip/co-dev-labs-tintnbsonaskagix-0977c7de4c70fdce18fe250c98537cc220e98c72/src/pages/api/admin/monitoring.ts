import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get user role from database
    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { role: true },
    });

    if (dbUser?.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Forbidden' });
    }

    // Get last 24 hours of logs
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    const [logs, totalRequests] = await Promise.all([
      prisma.systemLog.findMany({
        where: {
          timestamp: {
            gte: last24Hours,
          },
        },
        orderBy: {
          timestamp: 'desc',
        },
      }),
      prisma.systemLog.count({
        where: {
          timestamp: {
            gte: last24Hours,
          },
        },
      }),
    ]);

    // Calculate statistics
    const errorLogs = logs.filter(log => log.type === 'error');
    const errorRate = totalRequests > 0 ? (errorLogs.length / totalRequests) * 100 : 0;

    // Group requests by endpoint
    const endpointStats = logs.reduce((acc: any, log) => {
      if (log.endpoint) {
        if (!acc[log.endpoint]) {
          acc[log.endpoint] = {
            count: 0,
            errors: 0,
            avgResponseTime: 0,
            totalResponseTime: 0,
          };
        }
        acc[log.endpoint].count += 1;
        if (log.type === 'error') acc[log.endpoint].errors += 1;
        if (log.metadata?.responseTime) {
          acc[log.endpoint].totalResponseTime += log.metadata.responseTime;
          acc[log.endpoint].avgResponseTime = 
            acc[log.endpoint].totalResponseTime / acc[log.endpoint].count;
        }
      }
      return acc;
    }, {});

    const monitoringData = {
      totalRequests,
      errorRate,
      endpointStats,
      recentErrors: errorLogs.slice(0, 5),
      timestamp: new Date().toISOString(),
    };

    return res.status(200).json(monitoringData);
  } catch (error) {
    console.error('Error in monitoring endpoint:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}