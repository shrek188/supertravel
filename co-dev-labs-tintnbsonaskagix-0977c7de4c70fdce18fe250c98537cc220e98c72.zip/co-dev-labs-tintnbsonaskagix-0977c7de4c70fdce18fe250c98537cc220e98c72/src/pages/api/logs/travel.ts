import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { limit = '50', offset = '0', type } = req.query;

        const where = type ? {
            endpoint: {
                contains: type as string
            }
        } : {};

        const logs = await prisma.apiLog.findMany({
            where,
            take: parseInt(limit as string),
            skip: parseInt(offset as string),
            orderBy: {
                createdAt: 'desc'
            }
        });

        const total = await prisma.apiLog.count({ where });

        return res.status(200).json({
            logs,
            total,
            limit: parseInt(limit as string),
            offset: parseInt(offset as string)
        });
    } catch (error) {
        console.error('Error fetching logs:', error);
        return res.status(500).json({ 
            error: 'Failed to fetch logs',
            details: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}