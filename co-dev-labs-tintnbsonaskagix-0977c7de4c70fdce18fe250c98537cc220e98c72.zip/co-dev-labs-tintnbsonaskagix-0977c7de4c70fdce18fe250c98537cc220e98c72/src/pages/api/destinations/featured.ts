import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    console.log('Fetching featured destinations')
    const featuredDestinations = await prisma.destination.findMany({
      where: {
        featured: true
      },
      take: 5,
      orderBy: {
        createdAt: 'desc'
      },
      select: {
        id: true,
        name: true,
        description: true,
        imageUrl: true
      }
    })

    // Log successful request
    console.log(`Successfully fetched ${featuredDestinations.length} featured destinations`)

    return res.status(200).json(featuredDestinations)
  } catch (error) {
    console.error('Error in /api/destinations/featured:', error)
    return res.status(500).json({ 
      message: 'Error fetching featured destinations',
      error: process.env.NODE_ENV === 'development' ? error : undefined
    })
  }
}