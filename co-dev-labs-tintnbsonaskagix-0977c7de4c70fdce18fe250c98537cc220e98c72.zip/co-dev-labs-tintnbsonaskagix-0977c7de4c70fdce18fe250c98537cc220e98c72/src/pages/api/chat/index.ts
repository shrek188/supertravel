import { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@/util/supabase/api'
import prisma from '@/lib/prisma'
import OpenAI from 'openai'
import amadeus from '@/lib/amadeus'
import { logError } from '@/lib/logging'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const SYSTEM_PROMPT = `You are an AI travel assistant for SmartTrip, specialized in natural language travel planning.

Your primary capabilities include:
1. Flight search and recommendations
2. Hotel suggestions
3. Travel itinerary planning
4. Local attractions and activities
5. Travel tips and advice

When processing user queries:
- For flights: Extract origin, destination, dates, and preferences (e.g., "direct flights", "morning flights")
- For hotels: Identify location, dates, budget, and amenity preferences
- For activities: Understand user interests, time constraints, and budget considerations

Use these response formats:
1. For flight queries:
   🛫 Origin: [City/Airport]
   🛬 Destination: [City/Airport]
   📅 Date: [Travel Date]
   ✨ Preferences: [Any specific requirements]

2. For hotel queries:
   📍 Location: [City]
   🗓️ Dates: [Stay Period]
   💰 Budget: [Price Range]
   🏨 Preferences: [Amenities/Location]

3. For activity recommendations:
   🎯 Type: [Category]
   📍 Location: [Place]
   ⏱️ Duration: [Time needed]
   💡 Tips: [Practical advice]

Always maintain a helpful, friendly tone and provide specific, actionable recommendations.
If information is missing, ask clarifying questions to better assist the user.

Remember to suggest relevant quick actions:
- "Search flights" - When flight details are mentioned
- "Book hotels" - For accommodation queries
- "Explore activities" - For things to do
- "Plan itinerary" - For trip planning
- "Get travel tips" - For general advice, a travel planning platform. 
Your role is to help users plan their trips, provide travel recommendations, and share insights about destinations.
Keep responses friendly, informative, and concise (max 150 words).
Focus on practical, personalized travel advice.

When users ask about flights, extract the origin and destination information.
When users ask about hotels, identify the city and dates.
For general travel recommendations, provide specific suggestions based on user preferences.

If you don't know something specific, be honest and suggest alternatives.
Always maintain a helpful and enthusiastic tone about travel.

When appropriate, suggest one of these quick actions the user can take:
- "Search flights"
- "Book hotels"
- "Get destination recommendations"
- "Check weather"
- "Find activities"
- "Plan itinerary"
- "Get travel tips"

Vary your responses naturally and maintain conversation context.
Always format your responses with proper line breaks and spacing for readability.`

const MAX_HISTORY_LENGTH = 5 // Keep last 5 messages for context

// Function to detect user intent
interface TravelIntent {
  intent: 'flight_search' | 'hotel_search' | 'travel_recommendation' | 'general_inquiry' | 'itinerary_planning';
  details: {
    location?: string | null;
    dates?: string | null;
    preferences?: string | null;
    budget?: string | null;
    travelers?: number | null;
    duration?: string | null;
    activities?: string[] | null;
  };
  confidence: number;
}

async function detectIntent(message: string): Promise<TravelIntent> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `Analyze the user message and determine the travel-related intent and details.
Return JSON in format: {
  "intent": "flight_search" | "hotel_search" | "travel_recommendation" | "general_inquiry" | "itinerary_planning",
  "details": {
    "location": string | null,        // City, country, or region mentioned
    "dates": string | null,           // Travel dates or period
    "preferences": string | null,      // Any specific preferences mentioned
    "budget": string | null,          // Budget constraints if mentioned
    "travelers": number | null,        // Number of travelers if specified
    "duration": string | null,        // Duration of stay/trip if mentioned
    "activities": string[] | null     // List of activities or interests mentioned
  },
  "confidence": number                // Confidence score between 0 and 1
}

Examples:
1. "I want to fly from New York to London next week"
   {
     "intent": "flight_search",
     "details": {
       "location": "New York to London",
       "dates": "next week",
       "preferences": null,
       "budget": null,
       "travelers": null,
       "duration": null,
       "activities": null
     },
     "confidence": 0.95
   }

2. "Looking for hotels in Paris for 2 people, budget around $200 per night"
   {
     "intent": "hotel_search",
     "details": {
       "location": "Paris",
       "dates": null,
       "preferences": null,
       "budget": "200 USD per night",
       "travelers": 2,
       "duration": null,
       "activities": null
     },
     "confidence": 0.9
   }

3. "What are some fun things to do in Tokyo for a 5-day trip?"
   {
     "intent": "travel_recommendation",
     "details": {
       "location": "Tokyo",
       "dates": null,
       "preferences": "fun activities",
       "budget": null,
       "travelers": null,
       "duration": "5 days",
       "activities": ["sightseeing", "entertainment"]
     },
     "confidence": 0.85
   }
          Return JSON in format: {
            "intent": "flight_search" | "hotel_search" | "travel_recommendation" | "general_inquiry",
            "details": {
              "location": string | null,
              "dates": string | null,
              "preferences": string | null
            }
          }`
        },
        { role: "user", content: message }
      ],
      response_format: { type: "json_object" },
      max_tokens: 150,
      temperature: 0,
    })

    const result = JSON.parse(completion.choices[0]?.message?.content || '{"intent": "general_inquiry", "details": {}}')
    
    // Log intent detection
    await prisma.apiLog.create({
      data: {
        endpoint: 'intentDetection',
        request: { message },
        response: result,
        status: 200,
        duration: 0
      }
    })
    
    return result
  } catch (error) {
    logError('Error detecting intent:', error)
    return { intent: "general_inquiry", details: {} }
  }
}

// Function to extract flight information from message
async function extractFlightInfo(message: string) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `Extract flight search information from the message.
          Return JSON in format: {
            "origin": "IATA_CODE",
            "destination": "IATA_CODE",
            "date": "YYYY-MM-DD" // Extract date or use relative dates like "next week", "tomorrow"
          }
          Common IATA codes:
          - New York (JFK, EWR)
          - London (LHR)
          - Paris (CDG)
          - Los Angeles (LAX)
          - Tokyo (NRT)
          For dates:
          - "next week" = 7 days from today
          - "tomorrow" = tomorrow's date
          - "next month" = 30 days from today
          - If no specific date mentioned, use 7 days from today
          If no cities found or cannot determine IATA code, return null for those values.`
        },
        { role: "user", content: message }
      ],
      response_format: { type: "json_object" },
      max_tokens: 150,
      temperature: 0,
    })

    const result = JSON.parse(completion.choices[0]?.message?.content || '{"origin": null, "destination": null, "date": null}')
    
    // Convert relative dates to actual dates
    if (result.date) {
      const today = new Date()
      switch(result.date.toLowerCase()) {
        case 'next week':
          result.date = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          break
        case 'tomorrow':
          result.date = new Date(today.getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          break
        case 'next month':
          result.date = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          break
      }
    } else {
      // Default to 7 days from now
      result.date = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    }
    
    await prisma.apiLog.create({
      data: {
        endpoint: 'flightInfoExtraction',
        request: { message },
        response: result,
        status: 200,
        duration: 0
      }
    })
    
    return result
  } catch (error) {
    logError('Error extracting flight info:', error)
    return { origin: null, destination: null, date: null }
  }
}

// Function to search flights using Amadeus API
async function searchFlights(origin: string, destination: string, date?: string) {
  const requestPayload = {
    originLocationCode: origin,
    destinationLocationCode: destination,
    departureDate: date || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    adults: '1',
    max: 3
  }

  const startTime = Date.now()
  let logId: string | undefined
  
  try {
    // Create initial log entry
    const logEntry = await prisma.apiLog.create({
      data: {
        endpoint: 'flightOffersSearch',
        request: requestPayload,
        status: 0, // pending
        duration: 0
      }
    })
    logId = logEntry.id

    console.log('Searching flights with payload:', requestPayload)
    const response = await amadeus.shopping.flightOffersSearch.get(requestPayload)
    const duration = Date.now() - startTime

    // Validate response structure
    if (!response || !response.data) {
      throw new Error('Invalid response structure from Amadeus API')
    }
    
    // Update log with success response
    await prisma.apiLog.update({
      where: { id: logId },
      data: {
        response: {
          data: response.data,
          meta: response.meta,
          dictionaries: response.dictionaries
        },
        status: 200,
        duration
      }
    })

    return response.data.slice(0, 3).map((offer: any) => ({
      airline: offer.validatingAirlineCodes[0],
      price: {
        amount: offer.price.total,
        currency: offer.price.currency
      },
      departure: offer.itineraries[0].segments[0].departure.at,
      arrival: offer.itineraries[0].segments[0].arrival.at,
      duration: offer.itineraries[0].duration,
      segments: offer.itineraries[0].segments.length
    }))
  } catch (error) {
    const errorDetails = error instanceof Error ? {
      message: error.message,
      stack: error.stack,
      name: error.name
    } : 'Unknown error'
    
    await prisma.apiLog.create({
      data: {
        endpoint: 'flightOffersSearch',
        request: requestPayload,
        response: { error: errorDetails },
        status: 500,
        duration: Date.now() - startTime
      }
    })
    
    logError('Error searching flights:', {
      error: errorDetails,
      requestPayload,
      timestamp: new Date().toISOString()
    })
    return null
  }
}

// Function to format flight results as a response
function formatFlightResponse(flights: any[] | null) {
  if (!flights || flights.length === 0) {
    return "I apologize, but I couldn't find any flights matching your criteria at the moment. Would you like to try different dates or destinations?"
  }

  const lines = ["I found some flight options for you:\n"]
  
  flights.forEach((flight, index) => {
    lines.push(`Option ${index + 1}:`)
    lines.push(`🛫 Airline: ${flight.airline}`)
    lines.push(`⏰ Departure: ${new Date(flight.departure).toLocaleString()}`)
    lines.push(`🛬 Arrival: ${new Date(flight.arrival).toLocaleString()}`)
    lines.push(`💰 Price: ${flight.price.amount} ${flight.price.currency}`)
    lines.push(`⏱️ Duration: ${flight.duration}`)
    lines.push(`✈️ Stops: ${flight.segments > 1 ? (flight.segments - 1) + ' stop(s)' : 'Direct flight'}`)
    lines.push("")
  })
  
  lines.push("Would you like more details about any of these flights or would you like to search for different dates?")
  return lines.join("\n")
}

// Function to handle hotel search intent
async function handleHotelIntent(details: any) {
  return `I understand you're looking for a hotel${details.location ? ` in ${details.location}` : ''}${details.dates ? ` for ${details.dates}` : ''}. 
  
You can use our hotel search feature to find the perfect accommodation. Would you like me to help you with that?

Just click on the "Book hotels" button above, and I'll help you find the best options based on your preferences.`
}

// Function to handle travel recommendations
// Function to handle itinerary planning
async function handleItineraryPlanning(details: any) {
  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: `Create a detailed travel itinerary based on the user's preferences.
        Include:
        - Day-by-day schedule
        - Must-see attractions
        - Recommended restaurants
        - Transportation tips
        - Practical travel advice
        
        Format the response with emojis and clear sections.
        Keep suggestions realistic and time-efficient.
        Consider weather and seasonal factors if mentioned.`
      },
      {
        role: "user",
        content: `Create an itinerary for ${details.location || 'the destination'} 
                 ${details.duration ? `for ${details.duration}` : ''}
                 ${details.preferences ? `focusing on ${details.preferences}` : ''}
                 ${details.budget ? `with a budget of ${details.budget}` : ''}`
      }
    ],
    max_tokens: 500,
    temperature: 0.7,
  })

  return completion.choices[0]?.message?.content || "I apologize, but I need more details to create an itinerary. Could you please specify the destination and duration of your trip?"
}

async function handleRecommendations(details: any) {
  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: `You are a travel expert. Provide personalized travel recommendations based on the user's preferences.
        Keep the response concise but informative, including:
        - 2-3 specific destination suggestions
        - Best time to visit
        - Main attractions
        - One unique or lesser-known tip
        Format with appropriate line breaks and emojis for readability.`
      },
      {
        role: "user",
        content: `Provide recommendations for a user interested in ${details.preferences || 'travel'} ${details.location ? `in ${details.location}` : ''}`
      }
    ],
    max_tokens: 250,
    temperature: 0.7,
  })

  return completion.choices[0]?.message?.content || "I apologize, but I'm having trouble generating recommendations. Could you please provide more specific preferences?"
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  const startTime = Date.now()

  try {
    const supabase = createClient(req, res)
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      logError('Authentication error:', authError)
      return res.status(401).json({ message: 'Unauthorized' })
    }

    const { message, conversationHistory = [] } = req.body

    if (!message) {
      return res.status(400).json({ message: 'Message is required' })
    }

    // Detect user intent
    const intentData = await detectIntent(message)
    let aiResponse: string

    switch (intentData.intent) {
      case 'itinerary_planning':
        aiResponse = await handleItineraryPlanning(intentData.details)
        break
      case 'flight_search':
        const flightInfo = await extractFlightInfo(message)
        if (flightInfo.origin && flightInfo.destination) {
          const flights = await searchFlights(flightInfo.origin, flightInfo.destination, flightInfo.date)
          aiResponse = formatFlightResponse(flights)
        } else {
          aiResponse = "I understand you're looking for flights. Could you please specify your departure city and destination? For example: 'I need a flight from New York to London'"
        }
        break

      case 'hotel_search':
        aiResponse = await handleHotelIntent(intentData.details)
        break

      case 'travel_recommendation':
        aiResponse = await handleRecommendations(intentData.details)
        break

      default:
        // Regular chat response
        const messages = [
          { role: "system", content: SYSTEM_PROMPT },
          ...conversationHistory.slice(-MAX_HISTORY_LENGTH),
          { role: "user", content: message }
        ]

        const completion = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages,
          max_tokens: 300,
          temperature: 0.7,
        })

        aiResponse = completion.choices[0]?.message?.content || 
          "I apologize, but I'm having trouble processing your request. Could you please try again?"
    }

    // Log the interaction
    try {
      await prisma.chatInteraction.create({
        data: {
          userId: user.id,
          userMessage: message,
          aiResponse: aiResponse,
          context: JSON.stringify({
            history: conversationHistory.slice(-MAX_HISTORY_LENGTH).map(msg => ({
              role: msg.role,
              content: msg.content
            })),
            intent: {
              type: intentData.intent,
              details: intentData.details
            }
          }),
          duration: Date.now() - startTime
        },
      })
    } catch (logError) {
      console.error('Failed to log chat interaction:', logError)
      // Continue with the response even if logging fails
    }

    return res.status(200).json({ message: aiResponse })
  } catch (error) {
    logError('Chat handler error:', error)
    
    if (error instanceof OpenAI.APIError) {
      logError('OpenAI API Error:', {
        status: error.status,
        message: error.message,
        code: error.code,
        type: error.type
      })
    }
    
    return res.status(500).json({ 
      message: 'I apologize, but I encountered an error. Please try again in a moment.' 
    })
  }
}