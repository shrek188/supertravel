import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { message, userId } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Log the chat interaction
        const chatLog = await prisma.chatLog.create({
            data: {
                message,
                userId: userId || 'anonymous',
                type: 'SIMULATION',
                response: `Simulated response to: ${message}`,
                metadata: {
                    timestamp: new Date().toISOString(),
                    source: 'chat-simulation'
                }
            }
        });

        return res.status(200).json({
            success: true,
            response: `Simulated response to: ${message}`,
            logId: chatLog.id
        });
    } catch (error) {
        console.error('Chat simulation error:', error);
        return res.status(500).json({ 
            error: 'Failed to process chat simulation',
            details: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}