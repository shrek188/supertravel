import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'
import { logError } from '@/lib/logging'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method === 'GET') {
    try {
      const page = parseInt(req.query.page as string) || 1
      const limit = parseInt(req.query.limit as string) || 9
      const skip = (page - 1) * limit

      // Debug log
      console.log('Fetching posts with params:', { page, limit, skip })

      if (page < 1) {
        return res.status(400).json({ message: 'Page number must be greater than 0' })
      }

      if (limit < 1 || limit > 50) {
        return res.status(400).json({ message: 'Limit must be between 1 and 50' })
      }

      const [posts, total] = await Promise.all([
        prisma.post.findMany({
          skip,
          take: limit,
          orderBy: {
            createdAt: 'desc'
          },
          include: {
            author: {
              select: {
                id: true,
                email: true
              }
            },
            destination: {
              select: {
                name: true
              }
            }
          }
        }),
        prisma.post.count()
      ])

      // Log successful request
      console.log(`Successfully fetched ${posts.length} posts for page ${page}`)

      return res.status(200).json({
        posts,
        pagination: {
          page,
          limit,
          total,
          hasMore: skip + posts.length < total
        }
      })
    } catch (error) {
      logError('Error fetching posts:', error)
      return res.status(500).json({ 
        message: 'Error fetching posts',
        error: process.env.NODE_ENV === 'development' ? error : undefined
      })
    }
  } else if (req.method === 'POST') {
    try {
      const supabase = createClient(req, res)
      const { data: { user }, error: authError } = await supabase.auth.getUser()

      if (authError || !user) {
        return res.status(401).json({ message: 'Unauthorized' })
      }

      const { title, content, destinationId, mediaUrls } = req.body

      if (!title || !content) {
        return res.status(400).json({ message: 'Title and content are required' })
      }

      // Create post with transaction to ensure media is properly linked
      const post = await prisma.$transaction(async (tx) => {
        // Create the post first
        const newPost = await tx.post.create({
          data: {
            title,
            content,
            authorId: user.id,
            destinationId: destinationId || null,
          },
          include: {
            author: {
              select: {
                id: true,
                email: true
              }
            },
            destination: {
              select: {
                name: true
              }
            },
            media: true
          }
        });

        // If there are media URLs, create PostMedia entries
        if (mediaUrls && mediaUrls.length > 0) {
          await tx.postMedia.createMany({
            data: mediaUrls.map(url => ({
              postId: newPost.id,
              url: url,
              type: url.toLowerCase().match(/\.(jpg|jpeg|png|gif)$/) ? 'IMAGE' : 'VIDEO'
            }))
          });

          // Fetch the post again with media included
          return await tx.post.findUnique({
            where: { id: newPost.id },
            include: {
              author: {
                select: {
                  id: true,
                  email: true
                }
              },
              destination: {
                select: {
                  name: true
                }
              },
              media: true
            }
          });
        }

        return newPost;
      });

      return res.status(201).json(post)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      logError('Error creating post:', { error: errorMessage });

      // Handle specific error cases
      if (errorMessage.includes('Unauthorized')) {
        return res.status(401).json({ 
          message: 'Unauthorized access',
          error: 'Please log in to create posts'
        });
      }

      if (errorMessage.includes('storage')) {
        return res.status(400).json({ 
          message: 'Media upload failed',
          error: 'There was an error uploading your media. Please try again.'
        });
      }

      return res.status(500).json({ 
        message: 'Error creating post',
        error: process.env.NODE_ENV === 'development' ? errorMessage : 'Internal server error'
      });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' })
}