import { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@/util/supabase/api'

const TEST_ACCOUNTS = [
  { email: 'test@mvptest.com', password: process.env.TEST_ACCOUNT_PASSWORD || 'defaultTestPassword' },
]

interface AccountStatus {
  email: string
  password: string
  status: string
}

interface AccountError {
  email: string
  error: string
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  if (process.env.NEXT_PUBLIC_CO_DEV_ENV !== 'preview') {
    return res.status(403).json({ message: 'This endpoint is only available in preview environment' })
  }

  if (!process.env.TEST_ACCOUNT_PASSWORD) {
    return res.status(500).json({ message: 'TEST_ACCOUNT_PASSWORD environment variable is not set' })
  }

  try {
    const supabase = createClient(req, res)
    const createdAccounts: AccountStatus[] = []
    const errors: AccountError[] = []

    for (const account of TEST_ACCOUNTS) {
      console.log('Processing test account:', {
        email: account.email,
        timestamp: new Date().toISOString(),
        environment: process.env.NEXT_PUBLIC_CO_DEV_ENV
      })

      // First, check if the user exists
      const { data: existingUser } = await supabase.auth.admin.listUsers()
      const userExists = existingUser?.users?.some(user => user.email === account.email)

      if (userExists) {
        console.log('User exists, ensuring confirmation:', {
          email: account.email,
          timestamp: new Date().toISOString()
        })

        const existingUserData = existingUser?.users.find(user => user.email === account.email)
        
        if (!existingUserData) {
          errors.push({ email: account.email, error: 'User exists but data not found' })
          continue
        }

        // Update user to ensure they're confirmed and password is correct
        const { error: updateError } = await supabase.auth.admin.updateUserById(
          existingUserData.id,
          { 
            email_confirm: true,
            password: account.password
          }
        )

        if (updateError) {
          console.error('Error updating existing user:', {
            email: account.email,
            error: updateError.message,
            timestamp: new Date().toISOString()
          })
          errors.push({ email: account.email, error: updateError.message })
        } else {
          console.log('Successfully updated existing user:', {
            email: account.email,
            timestamp: new Date().toISOString()
          })
          createdAccounts.push({
            email: account.email,
            status: 'confirmed and password updated',
            password: account.password
          })
        }
      } else {
        console.log('Creating new test user:', {
          email: account.email,
          timestamp: new Date().toISOString()
        })

        // Create new user if doesn't exist
        const { data, error } = await supabase.auth.admin.createUser({
          email: account.email,
          password: account.password,
          email_confirm: true,
          user_metadata: {
            full_name: 'Test User'
          }
        })

        if (error) {
          console.error('Error creating new user:', {
            email: account.email,
            error: error.message,
            timestamp: new Date().toISOString()
          })
          errors.push({ email: account.email, error: error.message })
        } else {
          console.log('Successfully created new user:', {
            email: account.email,
            userId: data.user.id,
            timestamp: new Date().toISOString()
          })
          createdAccounts.push({
            email: account.email,
            status: 'created and confirmed',
            password: account.password
          })
        }
      }
    }

    // Log the final results
    console.log('Test accounts creation completed:', {
      created: createdAccounts.length,
      errors: errors.length,
      timestamp: new Date().toISOString()
    })

    return res.status(200).json({
      message: 'Test accounts processed',
      accounts: createdAccounts,
      errors: errors.length > 0 ? errors : undefined
    })
  } catch (error) {
    console.error('Error in test accounts creation:', {
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      timestamp: new Date().toISOString()
    })
    return res.status(500).json({ message: 'Internal server error', error: String(error) })
  }
}