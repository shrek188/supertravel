import { ChatInterface } from "@/components/ChatInterface"
import ProtectedRoute from "@/components/ProtectedRoute"

export default function ChatPage() {
  return (
    <ProtectedRoute>
      <div className="container py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          Travel AI Assistant
        </h1>
        <p className="text-center text-muted-foreground mb-8">
          Chat with our AI assistant to get personalized travel recommendations and tips
        </p>
        <ChatInterface />
      </div>
    </ProtectedRoute>
  )
}