import { useFormik } from 'formik';
import React, { useContext, useState } from 'react';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { AuthContext } from '@/contexts/AuthContext';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import GoogleButton from '@/components/GoogleButton';
import Logo from '@/components/Logo';
import { ReCaptcha } from '@/components/ReCaptcha';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";

const SignUpPage = () => {
  const router = useRouter();
  const { initializing, signUp } = useContext(AuthContext);
  const [showPw, setShowPw] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [captchaToken, setCaptchaToken] = useState<string>('');
  const { toast } = useToast();

  const handleSignUp = async (values: { email: string; password: string }) => {
    if (!captchaToken) {
      toast({
        variant: "destructive",
        title: "Verification Required",
        description: "Please complete the CAPTCHA verification"
      });
      return;
    }

    setIsLoading(true);
    try {
      // First verify the captcha
      const captchaVerification = await fetch('/api/auth/verify-captcha', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token: captchaToken }),
      });

      if (!captchaVerification.ok) {
        throw new Error('CAPTCHA verification failed');
      }

      const captchaResult = await captchaVerification.json();

      if (!captchaResult.success) {
        throw new Error('CAPTCHA verification failed');
      }

      const { email, password } = values;
      const result = await signUp(email, password);
      
      if (result?.user) {
        toast({
          title: "Success!",
          description: "Please check your email to confirm your account"
        });
        router.push('/login?message=Please check your email to confirm your account');
      }
    } catch (error: any) {
      console.error('Signup error:', error);
      
      if (error.message.includes("Email already registered") || error.message.includes("already registered")) {
        toast({
          variant: "destructive",
          title: "Account Exists",
          description: "This email is already registered. Please try logging in instead."
        });
        setTimeout(() => {
          router.push('/login');
        }, 2000);
      } else if (error.message.includes("signups not allowed") || error.message.includes("not allowed for this instance")) {
        toast({
          title: "Registration Notice",
          description: "New user registration is currently disabled. You will be redirected to get a test account."
        });
        setTimeout(() => {
          router.push('/test-accounts');
        }, 3000);
      } else {
        toast({
          variant: "destructive",
          title: "Signup Error",
          description: error.message || "Failed to create account. Please try again."
        });
      }
    } finally {
      setIsLoading(false);
    }
  }

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .required("Email is required")
      .email("Please enter a valid email address"),
    password: Yup.string()
      .required("Password is required")
      .min(6, "Password must be at least 6 characters")
      .max(40, "Password must not exceed 40 characters"),
  });

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema,
    onSubmit: handleSignUp,
  });

  const handleKeyPress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      formik.handleSubmit();
    }
  };

  return (
    <div className="flex min-h-screen bg-background justify-center items-center p-4">
      <div className="flex flex-col gap-5 w-full max-w-[440px]">
        <div className="w-full flex justify-center cursor-pointer" onClick={() => router.push("/")}>
          <Logo />
        </div>

        <Card className="w-full" onKeyDown={handleKeyPress}>
          <CardHeader>
            <CardTitle className="text-center">Create your account</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={formik.handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <GoogleButton />
                <div className="flex items-center w-full">
                  <Separator className="flex-1" />
                  <span className="mx-4 text-muted-foreground text-sm font-medium">or</span>
                  <Separator className="flex-1" />
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Enter your email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    disabled={isLoading}
                    className={formik.touched.email && formik.errors.email ? "border-destructive" : ""}
                  />
                  {formik.touched.email && formik.errors.email && (
                    <p className="text-destructive text-xs">{formik.errors.email}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPw ? 'text' : 'password'}
                      placeholder="Create a password"
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={isLoading}
                      className={formik.touched.password && formik.errors.password ? "border-destructive pr-10" : "pr-10"}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPw(!showPw)}
                      disabled={isLoading}
                    >
                      {showPw
                        ? <FaEye className="text-muted-foreground" />
                        : <FaEyeSlash className="text-muted-foreground" />
                      }
                    </Button>
                  </div>
                  {formik.touched.password && formik.errors.password && (
                    <p className="text-destructive text-xs">{formik.errors.password}</p>
                  )}
                </div>

                <div className="flex justify-center">
                  <ReCaptcha onVerify={(token) => setCaptchaToken(token)} />
                </div>

                <div className="flex justify-end text-sm">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <span>Already have an account?</span>
                    <Button
                      type="button"
                      variant="link"
                      className="p-0 h-auto"
                      onClick={() => router.push('/login')}
                      disabled={isLoading}
                    >
                      Log in
                    </Button>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || initializing || !formik.isValid || !captchaToken}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  'Create account'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SignUpPage;