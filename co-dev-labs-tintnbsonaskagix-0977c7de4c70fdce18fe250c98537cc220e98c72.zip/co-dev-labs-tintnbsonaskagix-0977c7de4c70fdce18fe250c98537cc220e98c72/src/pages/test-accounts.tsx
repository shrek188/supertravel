import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon, Loader2 } from "lucide-react"
import { toast } from "sonner"

interface TestAccount {
  email: string
  password: string
  status: string
}

export default function TestAccounts() {
  const [accounts, setAccounts] = useState<TestAccount[]>([])
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSeedingData, setSeedingData] = useState(false)

  const createTestAccounts = async () => {
    setIsLoading(true)
    setError('')

    try {
      const response = await fetch('/api/test-accounts/create', {
        method: 'POST',
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.message || 'Failed to create test accounts')
      }

      const data = await response.json()
      setAccounts(data.accounts)
      
      // After creating accounts, populate sample data
      await populateSampleData()
    } catch (error: any) {
      setError(error.message || 'An error occurred')
      toast.error('Failed to create test accounts')
    } finally {
      setIsLoading(false)
    }
  }

  const populateSampleData = async () => {
    setSeedingData(true)
    try {
      const response = await fetch('/api/seed-data', {
        method: 'POST',
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.message || 'Failed to populate sample data')
      }

      const data = await response.json()
      toast.success('Sample data populated successfully')
    } catch (error: any) {
      toast.error('Failed to populate sample data')
      console.error('Error populating sample data:', error)
    } finally {
      setSeedingData(false)
    }
  }

  if (process.env.NEXT_PUBLIC_CO_DEV_ENV !== 'preview') {
    return (
      <div className="container py-8">
        <h1 className="text-2xl font-bold text-center text-red-500">
          This page is only available in preview environment
        </h1>
      </div>
    )
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Test Accounts</h1>
      
      <div className="max-w-2xl mx-auto space-y-6">
        <Alert>
          <InfoIcon className="h-4 w-4" />
          <AlertTitle>New User Registration Notice</AlertTitle>
          <AlertDescription>
            New user registration is temporarily disabled. You can use one of the test accounts below to explore the application.
            All test accounts have full access to the platform's features.
          </AlertDescription>
        </Alert>

        <Card className="p-6">
          <div className="flex flex-col items-center gap-4 mb-6">
            <Button 
              onClick={createTestAccounts} 
              disabled={isLoading || isSeedingData}
              className="w-full max-w-xs"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating accounts...
                </>
              ) : (
                'Create Test Accounts'
              )}
            </Button>

            {isSeedingData && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Populating sample data...
              </div>
            )}
          </div>

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {accounts.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold mb-4">Available Accounts:</h2>
              {accounts.map((account, index) => (
                <div 
                  key={index}
                  className="p-4 border rounded-lg"
                >
                  <div className="font-mono">
                    <div>Email: {account.email}</div>
                    <div>Password: {account.password}</div>
                    <div className="text-sm text-muted-foreground">
                      Status: {account.status}
                    </div>
                  </div>
                </div>
              ))}
              <p className="text-sm text-muted-foreground mt-4">
                You can use any of these accounts to log in. All accounts have the same access level and features.
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}