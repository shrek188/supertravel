import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import FlightSearch from '@/components/travel/FlightSearch';
import HotelSearch from '@/components/travel/HotelSearch';
import ProtectedRoute from '@/components/ProtectedRoute';

export default function TravelPage() {
  return (
    <ProtectedRoute>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold text-center mb-8">Travel Search</h1>
        
        <Tabs defaultValue="flights" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="flights">Flights</TabsTrigger>
            <TabsTrigger value="hotels">Hotels</TabsTrigger>
          </TabsList>
          <TabsContent value="flights">
            <FlightSearch />
          </TabsContent>
          <TabsContent value="hotels">
            <HotelSearch />
          </TabsContent>
        </Tabs>
      </div>
    </ProtectedRoute>
  );
}