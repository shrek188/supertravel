import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/router';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

interface LogEntry {
  timestamp: string;
  message: string;
  type: 'error' | 'info' | 'success';
  endpoint?: string;
}

interface BookingActivity {
  id: string;
  timestamp: string;
  type: string;
  status: string;
  userId: string;
}

interface EndpointStat {
  count: number;
  errors: number;
  avgResponseTime: number;
}

interface MonitoringData {
  totalRequests: number;
  errorRate: number;
  endpointStats: Record<string, EndpointStat>;
  recentErrors: LogEntry[];
  timestamp: string;
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const router = useRouter();
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [bookings, setBookings] = useState<BookingActivity[]>([]);
  const [monitoringData, setMonitoringData] = useState<MonitoringData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkAdminAndFetchData = async () => {
      if (!user) {
        router.push('/login');
        return;
      }

      try {
        // Fetch all data in parallel
        const [logsResponse, bookingsResponse, monitoringResponse] = await Promise.all([
          fetch('/api/admin/logs'),
          fetch('/api/admin/bookings'),
          fetch('/api/admin/monitoring')
        ]);

        if (!logsResponse.ok) throw new Error('Failed to fetch logs');
        if (!bookingsResponse.ok) throw new Error('Failed to fetch booking activities');
        if (!monitoringResponse.ok) throw new Error('Failed to fetch monitoring data');

        const [logsData, bookingsData, monitoringData] = await Promise.all([
          logsResponse.json(),
          bookingsResponse.json(),
          monitoringResponse.json()
        ]);

        setLogs(logsData.logs);
        setBookings(bookingsData.bookings);
        setMonitoringData(monitoringData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    checkAdminAndFetchData();
    
    // Set up polling for monitoring data
    const pollInterval = setInterval(async () => {
      try {
        const response = await fetch('/api/admin/monitoring');
        if (response.ok) {
          const data = await response.json();
          setMonitoringData(data);
        }
      } catch (err) {
        console.error('Error polling monitoring data:', err);
      }
    }, 30000); // Poll every 30 seconds

    return () => clearInterval(pollInterval);
  }, [user, router]);

  if (loading) {
    return <div className="p-8">Loading...</div>;
  }

  if (error) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <Tabs defaultValue="monitoring" className="w-full">
        <TabsList>
          <TabsTrigger value="monitoring">System Monitoring</TabsTrigger>
          <TabsTrigger value="logs">System Logs</TabsTrigger>
          <TabsTrigger value="bookings">Booking Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="monitoring">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Overview Stats */}
            <Card className="p-4">
              <h3 className="text-lg font-semibold mb-2">System Overview</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Total Requests (24h)</span>
                    <span>{monitoringData?.totalRequests || 0}</span>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Error Rate</span>
                    <span>{(monitoringData?.errorRate || 0).toFixed(2)}%</span>
                  </div>
                  <Progress 
                    value={monitoringData?.errorRate || 0} 
                    className="h-2" 
                    indicatorClassName={monitoringData?.errorRate && monitoringData.errorRate > 5 ? "bg-red-500" : ""}
                  />
                </div>
              </div>
            </Card>

            {/* Endpoint Performance */}
            <Card className="p-4 col-span-2">
              <h3 className="text-lg font-semibold mb-2">Endpoint Performance</h3>
              <ScrollArea className="h-[300px] w-full">
                <div className="space-y-4">
                  {monitoringData?.endpointStats && Object.entries(monitoringData.endpointStats).map(([endpoint, stats]) => (
                    <div key={endpoint} className="border-b pb-2">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-mono text-sm">{endpoint}</span>
                        <span className="text-sm">
                          {stats.count} requests
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Error Rate: </span>
                          <span className={stats.errors/stats.count > 0.05 ? "text-red-500" : ""}>
                            {((stats.errors/stats.count) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Avg Response: </span>
                          <span>{stats.avgResponseTime ? `${stats.avgResponseTime.toFixed(0)}ms` : 'N/A'}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </Card>

            {/* Recent Errors */}
            <Card className="p-4 col-span-3">
              <h3 className="text-lg font-semibold mb-2">Recent Errors</h3>
              <ScrollArea className="h-[200px] w-full">
                {monitoringData?.recentErrors.map((error, index) => (
                  <div key={index} className="mb-2 p-2 bg-red-500/10 rounded border border-red-500/20">
                    <div className="text-sm text-muted-foreground">{error.timestamp}</div>
                    <div className="text-sm">{error.message}</div>
                    {error.endpoint && (
                      <div className="text-sm font-mono mt-1 text-muted-foreground">{error.endpoint}</div>
                    )}
                  </div>
                ))}
              </ScrollArea>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="logs">
          <Card className="p-4">
            <h2 className="text-xl font-semibold mb-4">Recent System Logs</h2>
            <ScrollArea className="h-[600px] w-full rounded-md border p-4">
              {logs.map((log, index) => (
                <div
                  key={index}
                  className={`mb-4 p-4 rounded-lg ${
                    log.type === 'error'
                      ? 'bg-red-50 border-red-200'
                      : log.type === 'success'
                      ? 'bg-green-50 border-green-200'
                      : 'bg-blue-50 border-blue-200'
                  } border`}
                >
                  <div className="text-sm text-gray-500">{log.timestamp}</div>
                  {log.endpoint && (
                    <div className="text-sm font-mono mt-1">{log.endpoint}</div>
                  )}
                  <div className="mt-1">{log.message}</div>
                </div>
              ))}
            </ScrollArea>
          </Card>
        </TabsContent>

        <TabsContent value="bookings">
          <Card className="p-4">
            <h2 className="text-xl font-semibold mb-4">Recent Booking Activity</h2>
            <ScrollArea className="h-[600px] w-full rounded-md border p-4">
              {bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="mb-4 p-4 rounded-lg bg-white border"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-sm text-gray-500">
                        {booking.timestamp}
                      </div>
                      <div className="font-medium">{booking.type}</div>
                      <div className="text-sm">User ID: {booking.userId}</div>
                    </div>
                    <div
                      className={`px-2 py-1 rounded-full text-sm ${
                        booking.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : booking.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {booking.status}
                    </div>
                  </div>
                </div>
              ))}
            </ScrollArea>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}