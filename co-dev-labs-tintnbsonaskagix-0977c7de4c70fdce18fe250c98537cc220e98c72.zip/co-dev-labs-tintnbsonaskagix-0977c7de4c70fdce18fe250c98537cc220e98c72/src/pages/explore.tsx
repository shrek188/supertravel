import React, { useState, useEffect } from "react";
import Head from "next/head";
import Header from "@/components/Header";
import PostCard from "@/components/PostCard";
import CreatePostDialog from "@/components/CreatePostDialog";
import AIAssistantButton from "@/components/AIAssistantButton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useInView } from "react-intersection-observer";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { ReloadIcon } from "@radix-ui/react-icons";
import { useAuth } from "@/contexts/AuthContext";

interface Media {
  id: string;
  url: string;
  type: 'IMAGE' | 'VIDEO';
}

interface Post {
  id: string;
  title: string;
  content: string;
  author: {
    id: string;
    email: string;
  };
  likes: number;
  destination?: {
    name: string;
  } | null;
  createdAt: string;
  media: Media[];
}

interface Destination {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
}

interface PaginatedResponse {
  posts: Post[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

export default function Explore() {
  const [seeding, setSeeding] = useState(false);
  const [seedError, setSeedError] = useState<string | null>(null);

  const seedData = async () => {
    try {
      setSeeding(true);
      setSeedError(null);
      const response = await fetch('/api/seed-data', {
        method: 'POST',
      });
      if (!response.ok) {
        throw new Error('Failed to seed data');
      }
      const data = await response.json();
      console.log('Seed data response:', data);
      // Refresh the page to show new data
      window.location.reload();
    } catch (error) {
      console.error('Error seeding data:', error);
      setSeedError('Failed to seed data. Please try again.');
    } finally {
      setSeeding(false);
    }
  };
  const [posts, setPosts] = useState<Post[]>([]);
  const [featuredDestinations, setFeaturedDestinations] = useState<Destination[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [destinationsError, setDestinationsError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const { ref, inView } = useInView({
    threshold: 0,
  });

  const fetchPosts = async (pageNum: number, isRetry: boolean = false) => {
    try {
      setError(null);
      const response = await fetch(`/api/posts?page=${pageNum}&limit=6`);
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      const data: PaginatedResponse = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching posts:', error);
      if (!isRetry) {
        setError('Failed to load posts. Please try again.');
      }
      return null;
    }
  };

  const fetchFeaturedDestinations = async (isRetry: boolean = false) => {
    try {
      setDestinationsError(null);
      const response = await fetch('/api/destinations/featured');
      if (!response.ok) {
        throw new Error('Failed to fetch destinations');
      }
      const data = await response.json();
      setFeaturedDestinations(data);
    } catch (error) {
      console.error('Error fetching featured destinations:', error);
      if (!isRetry) {
        setDestinationsError('Failed to load featured destinations. Please try again.');
      }
    }
  };

  const retryFetchPosts = async () => {
    setLoading(true);
    const data = await fetchPosts(1, true);
    if (data) {
      setPosts(data.posts);
      setHasMore(data.pagination.hasMore);
      setError(null);
    }
    setLoading(false);
  };

  const retryFetchDestinations = () => {
    fetchFeaturedDestinations(true);
  };

  useEffect(() => {
    let isMounted = true;

    const initializePage = async () => {
      try {
        setLoading(true);
        const [postsData, _] = await Promise.all([
          fetchPosts(1),
          fetchFeaturedDestinations()
        ]);
        
        if (isMounted && postsData) {
          setPosts(postsData.posts);
          setHasMore(postsData.pagination.hasMore);
        }
      } catch (error) {
        console.error('Error initializing page:', error);
        if (isMounted) {
          setError('Failed to load initial content. Please try again.');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initializePage();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let isMounted = true;
    let currentRequest: AbortController | null = null;

    const loadMore = async () => {
      if (inView && hasMore && !loadingMore && !loading && !error) {
        try {
          setLoadingMore(true);
          const nextPage = page + 1;
          
          // Cancel any ongoing request
          if (currentRequest) {
            currentRequest.abort();
          }
          
          // Create new abort controller for this request
          currentRequest = new AbortController();
          
          const data = await fetchPosts(nextPage);
          if (isMounted && data) {
            setPosts(prev => [...prev, ...data.posts]);
            setHasMore(data.pagination.hasMore);
            setPage(nextPage);
          }
        } catch (error) {
          if (error instanceof Error && error.name === 'AbortError') {
            // Ignore abort errors
            return;
          }
          console.error('Error loading more posts:', error);
        } finally {
          if (isMounted) {
            setLoadingMore(false);
          }
        }
      }
    };

    loadMore();

    return () => {
      isMounted = false;
      if (currentRequest) {
        currentRequest.abort();
      }
    };
  }, [inView, hasMore, loadingMore, loading, page, error]);

  const PostSkeleton = () => (
    <Card className="w-full">
      <CardContent className="p-4">
        <Skeleton className="w-full h-[300px] rounded-lg mb-4" />
        <Skeleton className="w-3/4 h-6 mb-2" />
        <Skeleton className="w-1/2 h-4" />
      </CardContent>
    </Card>
  );

  const DestinationSkeleton = () => (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <Skeleton className="w-full h-32" />
        <div className="p-3">
          <Skeleton className="w-3/4 h-4" />
        </div>
      </CardContent>
    </Card>
  );

  return (
    <>
      <Head>
        <title>Explore - Super Travel AI</title>
        <meta
          name="description"
          content="Explore amazing travel experiences and stories"
        />
      </Head>
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-6">
          {/* Seed Data Button */}
          {(posts.length === 0 || featuredDestinations.length === 0) && (
            <div className="mb-8">
              <Alert>
                <AlertDescription className="flex items-center justify-between">
                  No content found. Click the button below to populate the page with sample data.
                  <Button
                    onClick={seedData}
                    disabled={seeding}
                  >
                    {seeding ? (
                      <>
                        <ReloadIcon className="mr-2 h-4 w-4 animate-spin" />
                        Populating...
                      </>
                    ) : (
                      'Populate Sample Data'
                    )}
                  </Button>
                </AlertDescription>
              </Alert>
              {seedError && (
                <Alert variant="destructive" className="mt-2">
                  <AlertDescription>{seedError}</AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {/* Featured Destinations */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Featured Destinations</h2>
            {destinationsError ? (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription className="flex items-center justify-between">
                  {destinationsError}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={retryFetchDestinations}
                  >
                    <ReloadIcon className="mr-2 h-4 w-4" />
                    Retry
                  </Button>
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <DestinationSkeleton key={i} />
                  ))
                ) : (
                  featuredDestinations.map((destination) => (
                    <Card key={destination.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <img
                          src={destination.imageUrl}
                          alt={destination.name}
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-3">
                          <h3 className="font-semibold">{destination.name}</h3>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Categories/Filters */}
          <div className="mb-8">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="w-full justify-start bg-black/40 border-purple-800/30">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="following">Following</TabsTrigger>
                <TabsTrigger value="nearby">Nearby</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Error State */}
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription className="flex items-center justify-between">
                {error}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={retryFetchPosts}
                >
                  <ReloadIcon className="mr-2 h-4 w-4" />
                  Retry
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {loading ? (
              // Show skeletons while loading initial posts
              Array.from({ length: 6 }).map((_, i) => (
                <PostSkeleton key={i} />
              ))
            ) : (
              posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={{
                    id: post.id,
                    title: post.title,
                    description: post.content,
                    media: post.media,
                    author: {
                      name: post.author.email.split('@')[0],
                      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.author.id}`,
                    },
                    likes: post.likes,
                    comments: 0,
                    location: post.destination?.name || 'Unknown Location',
                  }}
                />
              ))
            )}
          </div>

          {/* Loading indicator */}
          <div
            ref={ref}
            className="w-full py-8 flex items-center justify-center"
          >
            {loadingMore && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                <PostSkeleton />
                <PostSkeleton />
              </div>
            )}
          </div>
        </main>

        {/* Create Post Dialog */}
        <CreatePostDialog onPostCreated={retryFetchPosts} />

        {/* AI Assistant Button */}
        <AIAssistantButton />
      </div>
    </>
  );
}