import { AuthContext } from "@/contexts/AuthContext";
import { useContext, useState } from "react";
import { FcGoogle } from 'react-icons/fc';
import { useIsIFrame } from "@/hooks/useIsIFrame";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/components/ui/use-toast";

const GoogleButton = () => {
  const { signInWithGoogle } = useContext(AuthContext);
  const { isIframe } = useIsIFrame();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleOpenNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      await signInWithGoogle();
    } catch (error: any) {
      if (error.message?.includes("not enabled") || error.message?.includes("unsupported provider")) {
        toast({
          variant: "destructive",
          title: "Google Sign In Unavailable",
          description: "Google authentication is temporarily unavailable. Please use email/password or try again later.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Authentication Error",
          description: error.message || "Failed to sign in with Google. Please try again.",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const button = (
    <button
      onClick={handleGoogleSignIn}
      disabled={isIframe || isLoading}
      className={`w-full flex items-center justify-center px-4 py-2 border border-neutral-700 rounded-md text-neutral-100 bg-neutral-800 ${
        !isIframe && !isLoading && "hover:bg-neutral-700"
      } transition-colors duration-200 ${
        (isIframe || isLoading) && "opacity-50 cursor-not-allowed"
      }`}
    >
      <FcGoogle className="mr-2" />
      {isLoading ? "Connecting..." : "Continue with Google"}
    </button>
  );

  return (
    <div className="h-10 w-full">
      {isIframe ? (
        <TooltipProvider delayDuration={0}>
          <Tooltip>
            <TooltipTrigger asChild>
              {button}
            </TooltipTrigger>
            <TooltipContent>
              <div>
                <p>Google Sign In is only available in the browser, not within developer mode. Click <button onClick={handleOpenNewTab} className="text-blue-500 hover:underline">here</button> to open in a new tab.</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ) : (
        button
      )}
    </div>
  );
};

export default GoogleButton;