import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { format } from "date-fns"
import { Calendar as CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export interface FlightSearchFormData {
  departureAirport: string
  destinationAirport: string
  departureDate: Date
  cabinClass: string
  travelers: number
}

interface FlightSearchFormProps {
  onSubmit: (data: FlightSearchFormData) => void
  isLoading?: boolean
}

export function FlightSearchForm({ onSubmit, isLoading = false }: FlightSearchFormProps) {
  const [departureAirport, setDepartureAirport] = useState("")
  const [destinationAirport, setDestinationAirport] = useState("")
  const [departureDate, setDepartureDate] = useState<Date>()
  const [cabinClass, setCabinClass] = useState("ECONOMY")
  const [travelers, setTravelers] = useState("1")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!departureAirport || !destinationAirport || !departureDate) return

    onSubmit({
      departureAirport: departureAirport.toUpperCase(),
      destinationAirport: destinationAirport.toUpperCase(),
      departureDate,
      cabinClass,
      travelers: parseInt(travelers, 10)
    })
  }

  return (
    <Card className="p-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="departureAirport">Departure Airport (IATA Code)</Label>
            <Input
              id="departureAirport"
              placeholder="e.g., LAX"
              value={departureAirport}
              onChange={(e) => setDepartureAirport(e.target.value)}
              maxLength={3}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="destinationAirport">Destination Airport (IATA Code)</Label>
            <Input
              id="destinationAirport"
              placeholder="e.g., JFK"
              value={destinationAirport}
              onChange={(e) => setDestinationAirport(e.target.value)}
              maxLength={3}
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Departure Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !departureDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {departureDate ? format(departureDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={departureDate}
                  onSelect={setDepartureDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Cabin Class</Label>
            <Select value={cabinClass} onValueChange={setCabinClass}>
              <SelectTrigger>
                <SelectValue placeholder="Select class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ECONOMY">Economy</SelectItem>
                <SelectItem value="PREMIUM_ECONOMY">Premium Economy</SelectItem>
                <SelectItem value="BUSINESS">Business</SelectItem>
                <SelectItem value="FIRST">First</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Number of Travelers</Label>
            <Select value={travelers} onValueChange={setTravelers}>
              <SelectTrigger>
                <SelectValue placeholder="Select number" />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                  <SelectItem key={num} value={num.toString()}>
                    {num} {num === 1 ? 'Traveler' : 'Travelers'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Searching..." : "Search Flights"}
        </Button>
      </form>
    </Card>
  )
}