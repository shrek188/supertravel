import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import { Card, CardContent } from "@/components/ui/card"

interface HotelDetailsProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  hotel: {
    name: string
    description?: string
    amenities?: string[]
    rating?: string
    photos?: string[]
    address?: {
      lines: string[]
      cityName?: string
      countryCode?: string
    }
    contact?: {
      phone?: string
      email?: string
    }
    hotelRating?: {
      overall?: number
      cleanliness?: number
      service?: number
      location?: number
    }
  }
}

export function HotelDetailsDialog({ open, onOpenChange, hotel }: HotelDetailsProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{hotel.name}</DialogTitle>
          <div className="flex items-center gap-2 mt-2">
            {hotel.rating && (
              <Badge variant="secondary">
                {hotel.rating} ★
              </Badge>
            )}
            {hotel.address && (
              <span className="text-sm text-gray-500">
                {hotel.address.lines.join(', ')}
                {hotel.address.cityName && `, ${hotel.address.cityName}`}
                {hotel.address.countryCode && `, ${hotel.address.countryCode}`}
              </span>
            )}
          </div>
        </DialogHeader>

        {hotel.photos && hotel.photos.length > 0 && (
          <div className="my-4">
            <Carousel>
              <CarouselContent>
                {hotel.photos.map((photo, index) => (
                  <CarouselItem key={index}>
                    <div className="aspect-video relative">
                      <img
                        src={photo}
                        alt={`${hotel.name} - Photo ${index + 1}`}
                        className="object-cover w-full h-full rounded-lg"
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>
        )}

        {hotel.description && (
          <div className="my-4">
            <h3 className="text-lg font-semibold mb-2">About</h3>
            <p className="text-gray-600">{hotel.description}</p>
          </div>
        )}

        {hotel.hotelRating && (
          <div className="my-4">
            <h3 className="text-lg font-semibold mb-2">Guest Ratings</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {hotel.hotelRating.overall && (
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-gray-500">Overall</div>
                    <div className="text-2xl font-bold">{hotel.hotelRating.overall}/5</div>
                  </CardContent>
                </Card>
              )}
              {hotel.hotelRating.cleanliness && (
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-gray-500">Cleanliness</div>
                    <div className="text-2xl font-bold">{hotel.hotelRating.cleanliness}/5</div>
                  </CardContent>
                </Card>
              )}
              {hotel.hotelRating.service && (
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-gray-500">Service</div>
                    <div className="text-2xl font-bold">{hotel.hotelRating.service}/5</div>
                  </CardContent>
                </Card>
              )}
              {hotel.hotelRating.location && (
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-gray-500">Location</div>
                    <div className="text-2xl font-bold">{hotel.hotelRating.location}/5</div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}

        {hotel.amenities && hotel.amenities.length > 0 && (
          <div className="my-4">
            <h3 className="text-lg font-semibold mb-2">Amenities</h3>
            <div className="flex flex-wrap gap-2">
              {hotel.amenities.map((amenity, index) => (
                <Badge key={index} variant="outline">
                  {amenity}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {hotel.contact && (
          <div className="my-4">
            <h3 className="text-lg font-semibold mb-2">Contact Information</h3>
            <div className="space-y-1 text-gray-600">
              {hotel.contact.phone && <div>Phone: {hotel.contact.phone}</div>}
              {hotel.contact.email && <div>Email: {hotel.contact.email}</div>}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}