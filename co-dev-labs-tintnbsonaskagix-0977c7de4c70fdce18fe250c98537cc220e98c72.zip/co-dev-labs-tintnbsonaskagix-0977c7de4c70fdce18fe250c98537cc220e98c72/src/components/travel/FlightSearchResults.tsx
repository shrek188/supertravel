import { Card } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

interface FlightOffer {
  id: string
  itineraries: Array<{
    segments: Array<{
      departure: {
        iataCode: string
        terminal?: string
        at: string
      }
      arrival: {
        iataCode: string
        terminal?: string
        at: string
      }
      carrierCode: string
      number: string
      duration: string
    }>
  }>
  price: {
    total: string
    currency: string
  }
  numberOfBookableSeats: number
}

interface FlightSearchResultsProps {
  results: FlightOffer[]
}

export function FlightSearchResults({ results }: FlightSearchResultsProps) {
  if (!results.length) {
    return (
      <Card className="p-4 text-center text-muted-foreground">
        No flights found matching your criteria.
      </Card>
    )
  }

  const formatDateTime = (dateTimeStr: string) => {
    const date = new Date(dateTimeStr)
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    })
  }

  const formatDuration = (duration: string) => {
    return duration
      .replace('PT', '')
      .replace('H', 'h ')
      .replace('M', 'm')
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-4 p-4">
        {results.map((flight) => (
          <Card key={flight.id} className="p-4">
            {flight.itineraries.map((itinerary, idx) => (
              <div key={idx} className="space-y-4">
                {itinerary.segments.map((segment, segIdx) => (
                  <div key={segIdx} className="flex justify-between items-center">
                    <div className="space-y-1">
                      <div className="font-medium">
                        {segment.carrierCode} {segment.number}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Duration: {formatDuration(segment.duration)}
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      <div>
                        <span className="font-medium">{segment.departure.iataCode}</span>
                        {segment.departure.terminal && ` (T${segment.departure.terminal})`}
                        <div className="text-sm text-muted-foreground">
                          {formatDateTime(segment.departure.at)}
                        </div>
                      </div>
                      <div>
                        <span className="font-medium">{segment.arrival.iataCode}</span>
                        {segment.arrival.terminal && ` (T${segment.arrival.terminal})`}
                        <div className="text-sm text-muted-foreground">
                          {formatDateTime(segment.arrival.at)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
            <div className="mt-4 pt-4 border-t flex justify-between items-center">
              <div className="text-sm text-muted-foreground">
                {flight.numberOfBookableSeats} seats available
              </div>
              <div className="text-lg font-semibold">
                {flight.price.currency} {flight.price.total}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </ScrollArea>
  )
}