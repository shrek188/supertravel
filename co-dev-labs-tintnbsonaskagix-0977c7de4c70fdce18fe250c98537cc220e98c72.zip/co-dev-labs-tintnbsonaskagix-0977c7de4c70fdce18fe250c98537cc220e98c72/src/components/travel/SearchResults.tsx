import { useState } from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { HotelDetailsDialog } from './HotelDetailsDialog';

interface FlightResult {
  itineraries: Array<{
    duration: string;
    segments: Array<{
      departure: {
        iataCode: string;
        at: string;
      };
      arrival: {
        iataCode: string;
        at: string;
      };
    }>;
  }>;
  price: {
    total: string;
  };
  validatingAirlineCodes: string[];
}

interface HotelResult {
  hotel: {
    name: string;
    rating?: string;
    description?: string;
    amenities?: string[];
    photos?: string[];
    hotelRating?: {
      overall?: number;
      cleanliness?: number;
      service?: number;
      location?: number;
    };
    address: {
      lines: string[];
      cityName?: string;
      countryCode?: string;
    };
    contact?: {
      phone?: string;
      email?: string;
    };
  };
  offers: Array<{
    price: {
      total: string;
    };
  }>;
}

interface SearchResultsProps {
  type: 'flights' | 'hotels';
  results: {
    data: FlightResult[] | HotelResult[];
    suggestions?: string[];
  };
  searchDates?: {
    checkInDate?: string;
    checkOutDate?: string;
  };
}

const formatDateTime = (dateTime: string) => {
  return new Date(dateTime).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

const formatDuration = (duration: string) => {
  return duration.replace('PT', '').toLowerCase();
};

export function SearchResults({ type, results, searchDates }: SearchResultsProps) {
  const [selectedHotel, setSelectedHotel] = useState<HotelResult | null>(null);
  const { data, suggestions = [] } = results;

  if (!data || data.length === 0) {
    return (
      <Card className="p-8">
        <div className="space-y-6">
          <div className="text-center">
            <p className="text-gray-700 font-medium mb-4">
              {type === 'hotels' 
                ? "No hotels found matching your criteria"
                : "No flights found matching your criteria"
              }
            </p>
            {suggestions.length > 0 ? (
              <>
                <p className="text-gray-600 text-sm mb-4">Here are some suggestions:</p>
                <ul className="text-gray-600 text-sm list-disc list-inside space-y-2">
                  {suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </>
            ) : (
              <ul className="text-gray-600 text-sm list-disc list-inside space-y-2">
                <li>The selected dates might not be available</li>
                <li>The location might have limited options</li>
                <li>Try adjusting your search criteria</li>
              </ul>
            )}
          </div>
          {suggestions.length > 0 && (
            <Alert>
              <AlertDescription>
                Try one of the suggested alternatives above to find available options.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </Card>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {type === 'flights' &&
          (data as FlightResult[]).map((flight, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="text-2xl font-bold">
                        {flight.itineraries[0].segments[0].departure.iataCode} →{' '}
                        {flight.itineraries[0].segments[flight.itineraries[0].segments.length - 1].arrival.iataCode}
                      </div>
                      <Badge variant="secondary" className="mt-1">
                        {flight.validatingAirlineCodes[0]}
                      </Badge>
                    </div>
                    <div className="text-xl font-bold text-green-600">
                      ${flight.price.total}
                    </div>
                  </div>
                  
                  <div className="space-y-2 border-t pt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Departure:</span>
                      <span className="font-medium">
                        {formatDateTime(flight.itineraries[0].segments[0].departure.at)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Arrival:</span>
                      <span className="font-medium">
                        {formatDateTime(flight.itineraries[0].segments[flight.itineraries[0].segments.length - 1].arrival.at)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Duration:</span>
                      <span className="font-medium">
                        {flight.itineraries[0].segments.reduce((total, segment) => 
                          total + formatDuration(segment.duration), '')}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Stops:</span>
                      <Badge variant="outline">
                        {flight.itineraries[0].segments.length - 1 === 0
                          ? 'Direct'
                          : `${flight.itineraries[0].segments.length - 1} stop${
                              flight.itineraries[0].segments.length - 1 > 1 ? 's' : ''
                            }`}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 p-4">
                <Button className="w-full" variant="secondary">
                  Select Flight
                </Button>
              </CardFooter>
            </Card>
          ))}

        {type === 'hotels' &&
          (data as HotelResult[]).map((hotel, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video relative bg-gray-100">
                {hotel.hotel.photos && hotel.hotel.photos[0] ? (
                  <img
                    src={hotel.hotel.photos[0]}
                    alt={hotel.hotel.name}
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-4xl font-bold text-gray-400">
                    {hotel.hotel.name.charAt(0)}
                  </div>
                )}
              </div>
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <h3 className="text-xl font-bold">{hotel.hotel.name}</h3>
                      <p className="text-sm text-gray-500">
                        {hotel.hotel.address.lines.join(', ')}
                      </p>
                      <div className="flex gap-2 flex-wrap">
                        {hotel.hotel.rating && (
                          <Badge variant="secondary">
                            {hotel.hotel.rating} ★
                          </Badge>
                        )}
                        {hotel.hotel.hotelRating?.overall && (
                          <Badge variant="outline">
                            Guest Rating: {hotel.hotel.hotelRating.overall}/5
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-xl font-bold text-green-600">
                      ${hotel.offers[0].price.total}
                      <span className="text-sm text-gray-500 block text-right">per night</span>
                    </div>
                  </div>
                  
                  {hotel.hotel.amenities && (
                    <div className="space-y-2">
                      <div className="text-sm text-gray-600">Popular amenities:</div>
                      <div className="flex flex-wrap gap-1">
                        {hotel.hotel.amenities.slice(0, 3).map((amenity, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {amenity}
                          </Badge>
                        ))}
                        {hotel.hotel.amenities.length > 3 && (
                          <Badge variant="outline" className="text-xs cursor-pointer hover:bg-gray-100"
                            onClick={() => setSelectedHotel(hotel)}>
                            +{hotel.hotel.amenities.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {hotel.hotel.hotelRating && (
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {hotel.hotel.hotelRating.overall && (
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-500">★</span>
                          <span>{hotel.hotel.hotelRating.overall}/5 Overall</span>
                        </div>
                      )}
                      {hotel.hotel.hotelRating.cleanliness && (
                        <div className="flex items-center gap-1">
                          <span className="text-blue-500">✨</span>
                          <span>{hotel.hotel.hotelRating.cleanliness}/5 Cleanliness</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {searchDates && (
                    <div className="space-y-2 border-t pt-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Check-in:</span>
                        <span className="font-medium">{searchDates.checkInDate}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Check-out:</span>
                        <span className="font-medium">{searchDates.checkOutDate}</span>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 p-4">
                <Button 
                  className="w-full" 
                  variant="secondary"
                  onClick={() => setSelectedHotel(hotel)}
                >
                  View Details
                </Button>
              </CardFooter>
            </Card>
          ))}
      </div>

      {selectedHotel && (
        <HotelDetailsDialog
          open={!!selectedHotel}
          onOpenChange={(open) => !open && setSelectedHotel(null)}
          hotel={selectedHotel.hotel}
        />
      )}
    </>
  );
}