import { useState } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import SearchResultSkeleton from './SearchResultSkeleton';
import { SearchResults } from './SearchResults';
import { FlightSearchForm, FlightSearchFormData } from './FlightSearchForm';

export default function FlightSearch() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [flights, setFlights] = useState<{ data: any[]; suggestions?: string[] }>({ data: [] });

  const handleSearch = async (searchParams: FlightSearchFormData) => {
    setLoading(true);
    setError('');
    setFlights({ data: [] });

    try {
      const response = await fetch('/api/travel/flights', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchParams),
      });

      let data;
      try {
        const text = await response.text();
        data = JSON.parse(text);
      } catch (parseError) {
        console.error('Response parsing error:', parseError);
        throw new Error('Invalid response format from server');
      }

      if (!response.ok) {
        throw new Error(data.error || 'Failed to search flights');
      }

      if (!data.data || data.data.length === 0) {
        setError('No flights found for the selected criteria. Please try different dates or airports.');
        return;
      }

      setFlights(data);
    } catch (err: any) {
      console.error('Flight search error:', err);
      setError(err.message || 'An error occurred while searching for flights');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <FlightSearchForm onSubmit={handleSearch} isLoading={loading} />

      {error && (
        <Alert variant="destructive" className="mt-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {loading ? (
        <div className="mt-6">
          <SearchResultSkeleton />
        </div>
      ) : (
        flights.data.length > 0 && (
          <div className="mt-6">
            <SearchResults type="flights" results={flights} />
          </div>
        )
      )}
    </div>
  );
}