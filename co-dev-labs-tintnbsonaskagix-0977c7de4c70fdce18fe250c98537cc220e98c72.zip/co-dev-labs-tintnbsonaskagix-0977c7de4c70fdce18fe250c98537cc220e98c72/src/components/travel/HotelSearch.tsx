import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import SearchResultSkeleton from './SearchResultSkeleton';
import { SearchResults } from './SearchResults';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { format, addDays } from 'date-fns';

const POPULAR_CITIES = [
  { code: 'PAR', name: 'Paris' },
  { code: 'LON', name: 'London' },
  { code: 'NYC', name: 'New York' },
  { code: 'TYO', name: 'Tokyo' },
  { code: 'ROM', name: 'Rome' },
  { code: 'SYD', name: 'Sydney' },
  { code: 'BKK', name: 'Bangkok' },
  { code: 'SIN', name: 'Singapore' },
  { code: 'DXB', name: 'Dubai' },
];

export default function HotelSearch() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [hotels, setHotels] = useState<{ data: any[]; meta?: any; suggestions?: string[] }>({ data: [] });
  const [searchParams, setSearchParams] = useState({
    cityCode: '',
    checkInDate: format(addDays(new Date(), 1), 'yyyy-MM-dd'),
    checkOutDate: format(addDays(new Date(), 3), 'yyyy-MM-dd'),
    adults: '1'
  });

  const validateDates = () => {
    const checkIn = new Date(searchParams.checkInDate);
    const checkOut = new Date(searchParams.checkOutDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (checkIn < today) {
      return 'Check-in date cannot be in the past';
    }
    if (checkOut <= checkIn) {
      return 'Check-out date must be after check-in date';
    }
    return '';
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const dateError = validateDates();
    if (dateError) {
      setError(dateError);
      return;
    }

    if (!searchParams.cityCode) {
      setError('Please select a destination city');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const queryParams = new URLSearchParams({
        ...searchParams,
        adults: searchParams.adults.toString()
      });
      const response = await fetch(`/api/travel/hotels?${queryParams}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to search hotels');
      }

      if (data.data && data.data.length === 0) {
        setError('No hotels found for the selected criteria. Try different dates or location.');
      }

      setHotels(data);
    } catch (err: any) {
      setError(err.message);
      setHotels({ data: [] });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchParams(prev => ({ ...prev, [name]: value }));
    setError(''); // Clear error when user makes changes
  };

  // Set minimum dates for check-in and check-out
  const today = format(new Date(), 'yyyy-MM-dd');
  const minCheckOut = searchParams.checkInDate 
    ? format(addDays(new Date(searchParams.checkInDate), 1), 'yyyy-MM-dd')
    : format(addDays(new Date(), 1), 'yyyy-MM-dd');

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <form onSubmit={handleSearch} className="space-y-4 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="citySelect">Destination City</Label>
            <Select
              onValueChange={(value) => {
                setSearchParams(prev => ({ ...prev, cityCode: value }));
                setError('');
              }}
              value={searchParams.cityCode}
            >
              <SelectTrigger id="citySelect">
                <SelectValue placeholder="Select a city" />
              </SelectTrigger>
              <SelectContent>
                {POPULAR_CITIES.map((city) => (
                  <SelectItem key={city.code} value={city.code}>
                    {city.name} ({city.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="adults">Number of Guests</Label>
            <Input
              id="adults"
              name="adults"
              type="number"
              min="1"
              max="9"
              placeholder="Number of guests"
              value={searchParams.adults}
              onChange={handleInputChange}
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="checkInDate">Check-in Date</Label>
            <Input
              id="checkInDate"
              name="checkInDate"
              type="date"
              min={today}
              value={searchParams.checkInDate}
              onChange={handleInputChange}
              required
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="checkOutDate">Check-out Date</Label>
            <Input
              id="checkOutDate"
              name="checkOutDate"
              type="date"
              min={minCheckOut}
              value={searchParams.checkOutDate}
              onChange={handleInputChange}
              required
              className="w-full"
            />
          </div>
        </div>

        <Button 
          type="submit" 
          disabled={loading} 
          className="w-full"
        >
          {loading ? 'Searching Hotels...' : 'Search Hotels'}
        </Button>
      </form>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {hotels.suggestions && hotels.suggestions.length > 0 && (
        <Alert className="mb-6">
          <AlertDescription>
            <ul className="list-disc pl-4">
              {hotels.suggestions.map((suggestion, index) => (
                <li key={index}>{suggestion}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {loading ? (
        <SearchResultSkeleton />
      ) : (
        <SearchResults 
          type="hotels" 
          results={hotels}
          searchDates={{
            checkInDate: searchParams.checkInDate,
            checkOutDate: searchParams.checkOutDate
          }}
        />
      )}
    </div>
  );
}