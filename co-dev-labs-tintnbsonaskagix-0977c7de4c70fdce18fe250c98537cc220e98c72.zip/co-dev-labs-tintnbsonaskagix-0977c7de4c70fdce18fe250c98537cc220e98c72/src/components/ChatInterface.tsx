import { useState, useEffect, useRef } from 'react'
import { formatFlightDataForChat } from '@/lib/flight-utils'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/contexts/AuthContext"
import { FlightSearchForm, FlightSearchFormData } from './travel/FlightSearchForm'
import { FlightSearchResults } from './travel/FlightSearchResults'
import { ConversationFlow, FlowStep } from './ConversationFlow'

interface Message {
  role: 'user' | 'assistant'
  content: string | React.ReactNode
  type?: 'text' | 'flight-search' | 'hotel-search'
}

const QUICK_ACTIONS = [
  "Search for flights",
  "Suggest a destination",
  "Check weather",
  "Find activities",
  "Plan itinerary",
  "Find accommodation"
]

const WELCOME_MESSAGES = [
  "Welcome to SmartTrip! How can I assist with your travel plans today?",
  "Hello! Ready to plan your next adventure?",
  "Hi there! Let's make your travel dreams come true. What can I help you with?",
  "Welcome aboard! Where shall we explore today?",
]

const FLIGHT_SEARCH_KEYWORDS = [
  'flight', 'flights', 'fly', 'book flight', 'search flights', 'find flights',
  'plane', 'airplane', 'travel from', 'travel to'
]

const HOTEL_SEARCH_KEYWORDS = [
  'hotel', 'hotels', 'accommodation', 'place to stay', 'book hotel', 'find hotel',
  'lodging', 'room', 'where to stay'
]

const DESTINATION_SEARCH_KEYWORDS = [
  'suggest', 'recommend', 'where should', 'destination', 'place to visit'
]

const FLIGHT_SEARCH_FLOW: FlowStep[] = [
  {
    id: 'departure',
    question: 'What is your departure city?',
    type: 'text',
    required: true
  },
  {
    id: 'destination',
    question: 'Where would you like to go?',
    type: 'text',
    required: true
  },
  {
    id: 'date',
    question: 'When would you like to travel?',
    type: 'date',
    required: true
  },
  {
    id: 'tripType',
    question: 'Is this a one-way or round trip?',
    type: 'options',
    options: ['One-way', 'Round trip'],
    required: true
  }
]

const HOTEL_SEARCH_FLOW: FlowStep[] = [
  {
    id: 'city',
    question: 'Which city are you looking to stay in?',
    type: 'text',
    required: true
  },
  {
    id: 'checkIn',
    question: 'What is your check-in date?',
    type: 'date',
    required: true
  },
  {
    id: 'checkOut',
    question: 'What is your check-out date?',
    type: 'date',
    required: true
  },
  {
    id: 'guests',
    question: 'How many adults are staying?',
    type: 'number',
    required: true
  }
]

const DESTINATION_RECOMMENDATION_FLOW: FlowStep[] = [
  {
    id: 'travelStyle',
    question: 'What type of travel experience are you looking for?',
    type: 'options',
    options: ['Beach & Relaxation', 'Cultural Experience', 'Adventure', 'City Break', 'Nature & Wildlife'],
    required: true
  },
  {
    id: 'budget',
    question: 'What is your budget range?',
    type: 'options',
    options: ['Budget', 'Moderate', 'Luxury'],
    required: true
  },
  {
    id: 'duration',
    question: 'How long do you plan to travel?',
    type: 'options',
    options: ['Weekend', '1 Week', '2 Weeks', 'More than 2 weeks'],
    required: true
  }
]

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [welcomeMessageSent, setWelcomeMessageSent] = useState(false)
  const [flightSearchResults, setFlightSearchResults] = useState<any[]>([])
  const [activeFlow, setActiveFlow] = useState<'flight' | 'destination' | 'hotel' | null>(null)
  const { user } = useAuth()
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (user && !welcomeMessageSent) {
      const randomWelcome = WELCOME_MESSAGES[Math.floor(Math.random() * WELCOME_MESSAGES.length)]
      setMessages([
        { 
          role: 'assistant', 
          content: randomWelcome,
          type: 'text'
        }
      ])
      setWelcomeMessageSent(true)
    }
  }, [user, welcomeMessageSent])

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const detectIntent = (message: string) => {
    const lowercaseMessage = message.toLowerCase()
    
    if (FLIGHT_SEARCH_KEYWORDS.some(keyword => lowercaseMessage.includes(keyword.toLowerCase()))) {
      return 'flight'
    }
    
    if (HOTEL_SEARCH_KEYWORDS.some(keyword => lowercaseMessage.includes(keyword.toLowerCase()))) {
      return 'hotel'
    }
    
    if (DESTINATION_SEARCH_KEYWORDS.some(keyword => lowercaseMessage.includes(keyword.toLowerCase()))) {
      return 'destination'
    }

    return null
  }

  const handleFlightSearch = async (data: FlightSearchFormData) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/travel/flights', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error('Failed to search flights')
      }

      const results = await response.json()
      
      if (results.data && results.data.length > 0) {
        setFlightSearchResults(results.data)
        const formattedFlights = results.data.map(formatFlightDataForChat).join('\n\n')
        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            content: `I found ${results.data.length} flights matching your criteria:\n\n${formattedFlights}`,
            type: 'flight-search'
          }
        ])
      } else {
        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            content: 'I couldn\'t find any flights matching your criteria. Would you like to try different dates or destinations?',
            type: 'text'
          }
        ])
      }
    } catch (error) {
      console.error('Flight search error:', error)
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: 'Sorry, I encountered an error while searching for flights. Please try again.',
          type: 'text'
        }
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleFlowComplete = async (answers: Record<string, string>) => {
    if (activeFlow === 'flight') {
      const flightData: FlightSearchFormData = {
        origin: answers.departure,
        destination: answers.destination,
        departureDate: answers.date,
        returnDate: answers.tripType === 'Round trip' ? answers.date : undefined,
      }
      await handleFlightSearch(flightData)
    } else if (activeFlow === 'hotel') {
      setIsLoading(true)
      try {
        const response = await fetch(`/api/travel/hotels?cityCode=${answers.city}&checkInDate=${answers.checkIn}&checkOutDate=${answers.checkOut}&adults=${answers.guests}`)
        
        if (!response.ok) {
          throw new Error('Failed to search hotels')
        }
        
        const results = await response.json()
        
        if (results.data && results.data.length > 0) {
          setMessages(prev => [
            ...prev,
            {
              role: 'assistant',
              content: `I found ${results.data.length} hotels in ${answers.city}. Here are some options:`,
              type: 'text'
            }
          ])
          
          // Add hotel search component
          const HotelSearch = (await import('./travel/HotelSearch')).HotelSearch
          setMessages(prev => [
            ...prev,
            {
              role: 'assistant',
              content: <HotelSearch
                cityCode={answers.city}
                checkInDate={answers.checkIn}
                checkOutDate={answers.checkOut}
                adults={Number(answers.guests)}
              />,
              type: 'hotel-search'
            }
          ])
        } else {
          setMessages(prev => [
            ...prev,
            {
              role: 'assistant',
              content: 'I couldn\'t find any hotels matching your criteria. Would you like to try different dates or location?',
              type: 'text'
            }
          ])
        }
      } catch (error) {
        console.error('Hotel search error:', error)
        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            content: 'Sorry, I encountered an error while searching for hotels. Please try again.',
            type: 'text'
          }
        ])
      } finally {
        setIsLoading(false)
      }
    } else if (activeFlow === 'destination') {
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: `Based on your preferences (${answers.travelStyle}, ${answers.budget} budget, ${answers.duration}), let me find some perfect destinations for you.`,
          type: 'text'
        }
      ])
      
      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: `Suggest travel destinations for someone looking for ${answers.travelStyle} experience, with ${answers.budget} budget, planning to travel for ${answers.duration}`,
            conversationHistory: []
          }),
        })

        if (!response.ok) {
          throw new Error('Failed to get recommendations')
        }

        const data = await response.json()
        setMessages(prev => [...prev, { role: 'assistant', content: data.message, type: 'text' }])
      } catch (error) {
        console.error('Destination recommendation error:', error)
        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            content: 'Sorry, I encountered an error while getting destination recommendations. Please try again.',
            type: 'text'
          }
        ])
      }
    }
    setActiveFlow(null)
    setIsLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage = input.trim()
    setInput('')
    setIsLoading(true)

    // Add user message to chat
    setMessages(prev => [...prev, { role: 'user', content: userMessage, type: 'text' }])

    // Detect intent
    const intent = detectIntent(userMessage)
    if (intent) {
      setActiveFlow(intent)
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: `I'll help you ${
            intent === 'flight' ? 'search for flights' : 
            intent === 'hotel' ? 'find a hotel' : 
            'find the perfect destination'
          }. Please answer a few questions:`,
          type: 'text'
        }
      ])
      setIsLoading(false)
      return
    }

    try {
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }))

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: userMessage,
          conversationHistory
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to get response')
      }

      const data = await response.json()
      setMessages(prev => [...prev, { role: 'assistant', content: data.message, type: 'text' }])
    } catch (error) {
      console.error('Chat error:', error)
      setMessages(prev => [
        ...prev,
        { 
          role: 'assistant', 
          content: 'Sorry, I encountered an error. Please try again.',
          type: 'text'
        }
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleQuickAction = (action: string) => {
    setInput(action)
    handleSubmit(new Event('submit') as any)
  }

  return (
    <Card className="w-full max-w-2xl mx-auto h-[600px] flex flex-col p-4">
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
          
          {activeFlow === 'flight' && (
            <div className="my-4">
              <ConversationFlow
                steps={FLIGHT_SEARCH_FLOW}
                onComplete={handleFlowComplete}
                onCancel={() => setActiveFlow(null)}
              />
            </div>
          )}

          {activeFlow === 'destination' && (
            <div className="my-4">
              <ConversationFlow
                steps={DESTINATION_RECOMMENDATION_FLOW}
                onComplete={handleFlowComplete}
                onCancel={() => setActiveFlow(null)}
              />
            </div>
          )}

          {activeFlow === 'hotel' && (
            <div className="my-4">
              <ConversationFlow
                steps={HOTEL_SEARCH_FLOW}
                onComplete={handleFlowComplete}
                onCancel={() => setActiveFlow(null)}
              />
            </div>
          )}

          {flightSearchResults.length > 0 && (
            <div className="my-4">
              <FlightSearchResults results={flightSearchResults} />
            </div>
          )}

          {messages.length === 0 && (
            <div className="text-center text-muted-foreground">
              Start a conversation with our AI travel assistant!
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2 mb-4">
        {QUICK_ACTIONS.map((action) => (
          <Button
            key={action}
            variant="outline"
            size="sm"
            onClick={() => handleQuickAction(action)}
            disabled={isLoading}
          >
            {action}
          </Button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about travel recommendations..."
          disabled={isLoading}
        />
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Sending..." : "Send"}
        </Button>
      </form>
    </Card>
  )
}