import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export interface FlowStep {
  id: string
  question: string
  type: 'text' | 'date' | 'options'
  options?: string[]
  required?: boolean
  validation?: (value: string) => boolean | string
}

interface ConversationFlowProps {
  steps: FlowStep[]
  onComplete: (answers: Record<string, string>) => void
  onCancel: () => void
}

export function ConversationFlow({ steps, onComplete, onCancel }: ConversationFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [error, setError] = useState<string | null>(null)

  const handleNext = () => {
    const currentStepData = steps[currentStep]
    const currentAnswer = answers[currentStepData.id]

    if (currentStepData.required && !currentAnswer) {
      setError('This field is required')
      return
    }

    if (currentStepData.validation && currentAnswer) {
      const validationResult = currentStepData.validation(currentAnswer)
      if (typeof validationResult === 'string') {
        setError(validationResult)
        return
      }
    }

    setError(null)
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onComplete(answers)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      setError(null)
    } else {
      onCancel()
    }
  }

  const handleInputChange = (value: string) => {
    setAnswers({
      ...answers,
      [steps[currentStep].id]: value
    })
    setError(null)
  }

  const currentStepData = steps[currentStep]

  return (
    <Card className="p-4 space-y-4">
      <div className="text-sm text-muted-foreground">
        Step {currentStep + 1} of {steps.length}
      </div>

      <div className="space-y-2">
        <Label>{currentStepData.question}</Label>

        {currentStepData.type === 'options' && currentStepData.options ? (
          <RadioGroup
            onValueChange={handleInputChange}
            value={answers[currentStepData.id]}
          >
            {currentStepData.options.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={option} />
                <Label htmlFor={option}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        ) : (
          <Input
            type={currentStepData.type}
            value={answers[currentStepData.id] || ''}
            onChange={(e) => handleInputChange(e.target.value)}
            placeholder={`Enter ${currentStepData.id}`}
          />
        )}

        {error && (
          <div className="text-sm text-red-500">{error}</div>
        )}
      </div>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={handleBack}
        >
          {currentStep === 0 ? 'Cancel' : 'Back'}
        </Button>
        <Button onClick={handleNext}>
          {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
        </Button>
      </div>
    </Card>
  )
}