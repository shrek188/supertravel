import React, { useEffect, useRef } from 'react';

declare global {
  interface Window {
    grecaptcha: any;
    onRecaptchaLoad: () => void;
  }
}

interface ReCaptchaProps {
  onVerify: (token: string) => void;
}

export const ReCaptcha: React.FC<ReCaptchaProps> = ({ onVerify }) => {
  const captchaRef = useRef<HTMLDivElement>(null);
  const scriptLoaded = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && !scriptLoaded.current) {
      // Load the reCAPTCHA script if it hasn't been loaded yet
      const existingScript = document.querySelector('script[src*="recaptcha"]');
      if (!existingScript) {
        const script = document.createElement('script');
        script.src = `https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit`;
        script.async = true;
        script.defer = true;
        scriptLoaded.current = true;

        // Define the callback function that will be called when the script loads
        window.onRecaptchaLoad = () => {
          if (captchaRef.current && window.grecaptcha) {
            try {
              window.grecaptcha.render(captchaRef.current, {
                sitekey: process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY,
                callback: onVerify,
                'expired-callback': () => onVerify(''),
              });
            } catch (error) {
              console.error('Error rendering reCAPTCHA:', error);
            }
          }
        };

        document.body.appendChild(script);
      }
    }

    return () => {
      if (scriptLoaded.current) {
        delete window.onRecaptchaLoad;
      }
    };
  }, [onVerify]);

  return (
    <div className="flex justify-center">
      <div ref={captchaRef} />
    </div>
  );
};