import React, { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2 } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Skeleton } from "@/components/ui/skeleton";

interface Media {
  id: string;
  url: string;
  type: 'IMAGE' | 'VIDEO';
}

interface PostCardProps {
  post: {
    id: string;
    title: string;
    description: string;
    media: Media[];
    author: {
      name: string;
      avatar: string;
    };
    likes: number;
    comments: number;
    location: string;
  };
}

export default function PostCard({ post }: PostCardProps) {
  const [mediaLoading, setMediaLoading] = useState<Record<string, boolean>>({});
  const [mediaError, setMediaError] = useState<Record<string, boolean>>({});

  const handleMediaLoad = (mediaId: string) => {
    setMediaLoading(prev => ({ ...prev, [mediaId]: false }));
    setMediaError(prev => ({ ...prev, [mediaId]: false }));
  };

  const handleMediaError = (mediaId: string) => {
    setMediaLoading(prev => ({ ...prev, [mediaId]: false }));
    setMediaError(prev => ({ ...prev, [mediaId]: true }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto overflow-hidden bg-black/40 border-purple-800/30">
      <CardHeader className="p-4">
        <div className="flex items-center space-x-4">
          <Avatar>
            <AvatarImage 
              src={post.author.avatar} 
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
              }}
            />
            <AvatarFallback>{post.author.name[0].toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="text-sm font-medium">{post.author.name}</p>
            <p className="text-xs text-muted-foreground">{post.location}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Carousel className="w-full">
          <CarouselContent>
            {post.media.map((item) => (
              <CarouselItem key={item.id}>
                <div className="relative aspect-[4/3] w-full">
                  {mediaLoading[item.id] && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Skeleton className="w-full h-full" />
                    </div>
                  )}
                  {mediaError[item.id] ? (
                    <div className="w-full h-full bg-muted flex items-center justify-center">
                      <p className="text-sm text-muted-foreground">Media unavailable</p>
                    </div>
                  ) : item.type === 'VIDEO' ? (
                    <video
                      src={item.url}
                      className="object-cover w-full h-full"
                      controls
                      onLoadStart={() => setMediaLoading(prev => ({ ...prev, [item.id]: true }))}
                      onLoadedData={() => handleMediaLoad(item.id)}
                      onError={() => handleMediaError(item.id)}
                    />
                  ) : (
                    <img
                      src={item.url}
                      alt={post.title}
                      className="object-cover w-full h-full"
                      onLoadStart={() => setMediaLoading(prev => ({ ...prev, [item.id]: true }))}
                      onLoad={() => handleMediaLoad(item.id)}
                      onError={() => handleMediaError(item.id)}
                    />
                  )}
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          {post.media.length > 1 && (
            <>
              <CarouselPrevious />
              <CarouselNext />
            </>
          )}
        </Carousel>
        <div className="p-4">
          <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
          <p className="text-muted-foreground">{post.description}</p>
        </div>
      </CardContent>
      <CardFooter className="p-4 flex justify-between border-t border-purple-800/30">
        <div className="flex space-x-4">
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            <Heart className="h-5 w-5 mr-1" />
            {post.likes}
          </Button>
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            <MessageCircle className="h-5 w-5 mr-1" />
            {post.comments}
          </Button>
        </div>
        <Button variant="ghost" size="sm" className="text-muted-foreground">
          <Share2 className="h-5 w-5" />
        </Button>
      </CardFooter>
    </Card>
  );
}