import React, { createContext, useState, ReactNode, useContext, useEffect } from 'react';
import { createClient } from '@/util/supabase/component';
import { User, Provider } from '@supabase/supabase-js';
import { useToast } from "@/components/ui/use-toast";
import { useRouter } from 'next/router';

interface AuthContextType {
  user: User | null;
  createUser: (user: User) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<any>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  initializing: boolean;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  createUser: async () => {},
  signIn: async () => {},
  signUp: async () => {},
  signInWithGoogle: async () => {},
  signOut: async () => {},
  resetPassword: async () => {},
  initializing: false
});

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const supabase = createClient();
  const { toast } = useToast();

  React.useEffect(() => {
    const fetchSession = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      setInitializing(false);
    };

    fetchSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null);
      setInitializing(false);
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const createUser = async (user: User) => {
    try {
      const { data, error } = await supabase
        .from('User')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();
      if (error && error.code !== 'PGRST116') {
        throw error;
      }
      if (!data) {
        const { error: insertError } = await supabase
          .from('User')
          .insert({
            id: user.id,
            email: user.email,
          });
        if (insertError) {
          throw insertError;
        }
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create user profile",
      });
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const normalizedEmail = email.trim().toLowerCase();
      
      // Enhanced input validation with specific error messages
      if (!normalizedEmail) {
        throw new Error("Please enter your email address");
      }
      if (!password) {
        throw new Error("Please enter your password");
      }
      if (password.length < 4) {
        throw new Error("Password must be at least 4 characters long");
      }

      // Log sign in attempt with more context
      console.log('Starting sign in process:', {
        email: normalizedEmail,
        timestamp: new Date().toISOString(),
        environment: process.env.NEXT_PUBLIC_CO_DEV_ENV,
        hasPassword: !!password,
        passwordLength: password.length
      });
      
      // Strict email format validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(normalizedEmail)) {
        throw new Error("Please enter a valid email address");
      }

      // First check if user exists
      const { data: { users }, error: usersError } = await supabase.auth.admin.listUsers();
      
      if (usersError) {
        console.error('Error checking user existence:', {
          error: usersError,
          email: normalizedEmail,
          timestamp: new Date().toISOString()
        });
      } else {
        const userExists = users?.some(user => user.email === normalizedEmail);
        if (!userExists) {
          console.log('User not found:', {
            email: normalizedEmail,
            timestamp: new Date().toISOString()
          });
          throw new Error("No account found with this email address. Please sign up first.");
        }
      }

      // Attempt authentication
      const { data, error } = await supabase.auth.signInWithPassword({ 
        email: normalizedEmail, 
        password 
      });
      
      if (error) {
        // Detailed error logging for debugging
        console.error('Sign in error details:', {
          message: error.message,
          status: error.status,
          name: error.name,
          email: normalizedEmail,
          timestamp: new Date().toISOString(),
          errorCode: error.status,
          errorType: error.name,
          rawError: JSON.stringify(error)
        });
        
        // Enhanced error mapping with specific messages
        switch(true) {
          case error.message.includes("Invalid login credentials"):
          case error.status === 400:
          case error.message.includes("invalid"):
            // Try to create/update test account if in preview environment
            if (process.env.NEXT_PUBLIC_CO_DEV_ENV === 'preview' && normalizedEmail === 'test@mvptest.com') {
              console.log('Attempting to reset test account...');
              try {
                const response = await fetch('/api/test-accounts/create', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' }
                });
                if (response.ok) {
                  console.log('Test account reset successful');
                  // Retry authentication after reset
                  const retryAuth = await supabase.auth.signInWithPassword({ 
                    email: normalizedEmail, 
                    password 
                  });
                  if (!retryAuth.error && retryAuth.data?.user) {
                    return retryAuth;
                  }
                }
              } catch (resetError) {
                console.error('Error resetting test account:', resetError);
              }
            }
            throw new Error("The email or password you entered is incorrect. Please check your credentials and try again.");
          case error.message.includes("Email not confirmed"):
            throw new Error("Please verify your email address before logging in. Check your inbox for the confirmation link.");
          case error.message.includes("Too many requests"):
          case error.status === 429:
            throw new Error("Too many login attempts. Please wait a few minutes before trying again.");
          case error.message.includes("network"):
          case error.message.includes("timeout"):
            throw new Error("Network error. Please check your internet connection and try again.");
          case error.message.includes("not found"):
            throw new Error("No account found with this email address. Please sign up first.");
          default:
            // Log unhandled errors for monitoring
            console.error('Unhandled auth error:', {
              error: error,
              email: normalizedEmail,
              timestamp: new Date().toISOString(),
              context: 'signIn'
            });
            throw new Error("An unexpected error occurred. Please try again later.");
        }
      }

      // Enhanced user data validation
      if (!data?.user) {
        console.error('Authentication anomaly:', {
          email: normalizedEmail,
          timestamp: new Date().toISOString(),
          error: 'No user data in successful response',
          responseData: JSON.stringify(data)
        });
        throw new Error("Authentication failed. Please try again.");
      }

      // Log successful authentication with more details
      console.log('Authentication successful:', {
        userId: data.user.id,
        email: normalizedEmail,
        timestamp: new Date().toISOString(),
        provider: data.user.app_metadata?.provider || 'email',
        lastSignIn: data.user.last_sign_in_at
      });
      
      // Create or update user profile
      await createUser(data.user);
      
      // Enhanced success message
      toast({
        title: "Welcome back!",
        description: `You've successfully signed in as ${normalizedEmail}`,
        duration: 3000,
      });

      return data;

    } catch (error: any) {
      // Enhanced error logging with more context
      console.error("Sign in error:", {
        message: error.message,
        stack: error.stack,
        name: error.name,
        timestamp: new Date().toISOString(),
        type: error.constructor.name,
        code: error.code
      });
      
      // Re-throw the error with enhanced message if needed
      throw error;
    }
  };

  const signUp = async (email: string, password: string) => {
    try {
      const normalizedEmail = email.trim().toLowerCase();
      console.log('Starting sign up process:', {
        email: normalizedEmail,
        timestamp: new Date().toISOString(),
        environment: process.env.NEXT_PUBLIC_CO_DEV_ENV
      });

      const { data, error } = await supabase.auth.signUp({
        email: normalizedEmail,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      console.log('Sign up attempt result:', {
        success: !!data?.user,
        email: normalizedEmail,
        timestamp: new Date().toISOString(),
        errorPresent: !!error,
        identitiesLength: data?.user?.identities?.length
      });

      if (error) {
        console.error('Sign up error details:', {
          message: error.message,
          status: error.status,
          name: error.name,
          email: normalizedEmail,
          timestamp: new Date().toISOString()
        });

        let errorMessage = error.message;
        if (error.message.includes("duplicate key")) {
          errorMessage = "This email is already registered. Please try logging in instead.";
        } else if (error.message.includes("signups not allowed") || error.message.includes("not allowed for this instance")) {
          errorMessage = "New user registration is temporarily disabled. Please use the test account or contact support for assistance.";
          router.push('/test-accounts');
        }

        toast({
          variant: "destructive",
          title: "Sign Up Error",
          description: errorMessage,
        });
        throw new Error(errorMessage);
      }

      if (data?.user?.identities?.length === 0) {
        console.log('Email already registered:', {
          email: normalizedEmail,
          timestamp: new Date().toISOString()
        });
        
        toast({
          variant: "destructive",
          title: "Sign Up Error",
          description: "This email is already registered. Please try logging in instead.",
        });
        throw new Error("Email already registered");
      }

      if (data.user) {
        console.log('Sign up successful:', {
          userId: data.user.id,
          email: normalizedEmail,
          timestamp: new Date().toISOString()
        });
        
        await createUser(data.user);
        toast({
          title: "Success",
          description: "Please check your email to confirm your account.",
        });
      } else {
        console.error('Sign up anomaly:', {
          email: normalizedEmail,
          timestamp: new Date().toISOString(),
          error: 'No user data in successful response'
        });
        throw new Error("Unable to complete signup. Please try again.");
      }

      return data;
    } catch (error: any) {
      console.error("Sign up error:", {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      throw error;
    }
  };



  const signInWithGoogle = async () => {
    try {
      console.log('Starting Google sign in process');
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google' as Provider,
        options: {
          redirectTo: `${window.location.origin}/auth/callback`
        }
      });
      
      if (error) {
        console.error('Google sign in error:', {
          message: error.message,
          status: error.status,
          name: error.name,
          timestamp: new Date().toISOString()
        });

        let errorMessage = error.message;
        if (error.message.includes("not enabled") || error.message.includes("unsupported provider")) {
          errorMessage = "Google authentication is not available at the moment. Please use email/password or try again later.";
        }

        toast({
          variant: "destructive",
          title: "Google Sign In Error",
          description: errorMessage,
        });
        throw error;
      }

      if (data) {
        console.log('Google sign in initiated successfully');
      }
    } catch (error: any) {
      console.error('Google sign in exception:', {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      throw error;
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } else {
      toast({
        title: "Success",
        description: "You have successfully signed out",
      });
      router.push('/');
    }
  };

  const resetPassword = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
      throw error;
    } else {
      toast({
        title: "Success",
        description: "Check your email for the password reset link",
      });
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      createUser,
      signIn,
      signUp,
      signInWithGoogle,
      signOut,
      resetPassword,
      initializing
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);