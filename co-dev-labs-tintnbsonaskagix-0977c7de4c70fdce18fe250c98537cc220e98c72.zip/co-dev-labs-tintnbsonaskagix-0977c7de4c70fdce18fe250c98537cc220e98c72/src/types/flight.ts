export interface FlightOffer {
  id: string
  itineraries: Array<{
    segments: Array<{
      departure: {
        iataCode: string
        terminal?: string
        at: string
      }
      arrival: {
        iataCode: string
        terminal?: string
        at: string
      }
      carrierCode: string
      number: string
      duration: string
    }>
  }>
  price: {
    total: string
    currency: string
  }
  numberOfBookableSeats: number
}