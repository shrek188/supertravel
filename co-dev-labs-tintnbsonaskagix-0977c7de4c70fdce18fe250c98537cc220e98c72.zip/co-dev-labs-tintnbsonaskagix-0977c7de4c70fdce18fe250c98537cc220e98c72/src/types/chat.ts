export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export interface PresetResponse {
  keywords: string[];
  response: string;
}